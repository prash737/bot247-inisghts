"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Loader2, Upload, X } from "lucide-react"
import Link from "next/link"
import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { TestimonialCarousel } from "@/app/components/testimonial-carousel"
import { Footer } from "@/app/components/footer"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { supabaseSignup } from "@/app/utils/supabaseClientSignup"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Image from "next/image"
import { toast } from "@/components/ui/use-toast"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { InfoIcon as InfoCircle } from "lucide-react"

// Initialize Supabase client
const supabase = supabaseSignup

const roleOptions = [
  "Business Owner",
  "Developer",
  "Marketing Manager",
  "Sales Representative",
  "Customer Support",
  "Other",
]

const timezoneOptions = [
  "GMT-11:00 - Pacific/Midway",
  "GMT-10:00 - America/Adak",
  "GMT-09:00 - America/Anchorage",
  "GMT-08:00 - America/Los_Angeles",
  "GMT-07:00 - America/Denver",
  "GMT-06:00 - America/Chicago",
  "GMT-05:00 - America/New_York",
  "GMT-04:00 - America/Caracas",
  "GMT-03:00 - America/Santiago",
  "GMT-03:00 - America/Sao_Paulo",
  "GMT-02:00 - Atlantic/South_Georgia",
  "GMT-01:00 - Atlantic/Azores",
  "GMT+00:00 - Europe/London",
  "GMT+01:00 - Europe/Berlin",
  "GMT+03:00 - Europe/Istanbul",
  "GMT+02:00 - Africa/Cairo",
  "GMT+03:00 - Europe/Moscow",
  "GMT+04:00 - Asia/Dubai",
  "GMT+05:00 - Asia/Karachi",
  "GMT+05:30 - Asia/Kolkata",
  "GMT+06:00 - Asia/Dhaka",
  "GMT+07:00 - Asia/Bangkok",
  "GMT+08:00 - Asia/Shanghai",
  "GMT+09:00 - Asia/Tokyo",
  "GMT+10:00 - Australia/Sydney",
  "GMT+12:00 - Pacific/Auckland",
  "GMT+12:00 - Pacific/Fiji",
]

export default function SignUpPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [company, setCompany] = useState("")
  const [role, setRole] = useState("")
  const [timezone, setTimezone] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const [chatbotName, setChatbotName] = useState("")

  // Avatar upload state
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    setSelectedFile(file)

    // Create preview URL
    const reader = new FileReader()
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleBrowseClick = () => {
    fileInputRef.current?.click()
  }

  const handleRemoveFile = () => {
    setSelectedFile(null)
    setPreviewUrl(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()

    const file = e.dataTransfer.files?.[0]
    if (!file) return

    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      })
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB",
        variant: "destructive",
      })
      return
    }

    setSelectedFile(file)

    // Create preview URL
    const reader = new FileReader()
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const uploadAvatar = async (chatbotId: string) => {
    if (!selectedFile) return

    try {
      // Generate a unique filename with timestamp
      const timestamp = new Date().getTime()
      const fileExtension = selectedFile.name.split(".").pop()
      const fileName = `avatar_${timestamp}.${fileExtension}`
      const filePath = `${chatbotId}/${fileName}`

      // Upload the file
      const { error: uploadError } = await supabaseSignup.storage
        .from("profile_pictures")
        .upload(filePath, selectedFile, {
          cacheControl: "3600",
          upsert: true,
        })

      if (uploadError) {
        throw new Error(`Failed to upload avatar: ${uploadError.message}`)
      }
    } catch (error) {
      console.error("Error uploading avatar:", error)
      toast({
        title: "Avatar upload failed",
        description: error instanceof Error ? error.message : "Failed to upload avatar",
        variant: "destructive",
      })
    }
  }

  // Add a new function to validate password strength
  function validatePassword(password: string, username: string): { isValid: boolean; message: string } {
    // Check password length
    if (password.length < 8) {
      return { isValid: false, message: "Password must be at least 8 characters long" }
    }

    // Check for uppercase letter
    if (!/[A-Z]/.test(password)) {
      return { isValid: false, message: "Password must contain at least one uppercase letter" }
    }

    // Check for lowercase letter
    if (!/[a-z]/.test(password)) {
      return { isValid: false, message: "Password must contain at least one lowercase letter" }
    }

    // Check for number
    if (!/[0-9]/.test(password)) {
      return { isValid: false, message: "Password must contain at least one number" }
    }

    // Check for special character
    if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
      return { isValid: false, message: "Password must contain at least one special character" }
    }

    // Check if password contains parts of the username (email)
    if (username) {
      const emailParts = username.split("@")
      const usernameWithoutDomain = emailParts[0]

      // Check if username (without domain) is at least 4 characters
      if (usernameWithoutDomain.length >= 4 && password.toLowerCase().includes(usernameWithoutDomain.toLowerCase())) {
        return { isValid: false, message: "Password should not contain parts of your email address" }
      }

      // If domain exists and is at least 4 characters, check for it too
      if (emailParts.length > 1) {
        const domain = emailParts[1].split(".")[0]
        if (domain.length >= 4 && password.toLowerCase().includes(domain.toLowerCase())) {
          return { isValid: false, message: "Password should not contain parts of your email address" }
        }
      }
    }

    return { isValid: true, message: "" }
  }

  // Update the handleSignUp function to include password validation
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(username)) {
      setError("Please enter a valid email address")
      setIsLoading(false)
      return
    }

    // Password validation
    const passwordValidation = validatePassword(password, username)
    if (!passwordValidation.isValid) {
      setError(passwordValidation.message)
      setIsLoading(false)
      return
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match")
      setIsLoading(false)
      return
    }

    // Validate mandatory fields
    if (!firstName.trim()) {
      setError("First name is required")
      setIsLoading(false)
      return
    }

    if (!company.trim()) {
      setError("Company name is required")
      setIsLoading(false)
      return
    }

    if (!chatbotName.trim()) {
      setError("Chatbot name is required")
      setIsLoading(false)
      return
    }

    try {
      // Check if username (email) already exists
      const { data: existingUser } = await supabaseSignup
        .from("credentials")
        .select("username")
        .eq("username", username)
        .single()

      if (existingUser) {
        setError("Email already exists. Please use a different email address.")
        setIsLoading(false)
        return
      }

      // Hash the password before storing it
      const hashedPassword = await hashPassword(password)
      const chatbotId = `cb_${Date.now()}`

      // Insert initial user data into credentials table with hashed password
      const { error: credentialsError } = await supabaseSignup.from("credentials").insert([
        {
          username,
          password: hashedPassword, // Store the hashed password instead of plain text
          chatbot_id: chatbotId,
          selected_plan: null,
          chatbot_status: "Inactive",
          selected_domain: null,
          first_name: firstName,
          last_name: lastName,
          company: company,
          role: role,
          timezone: timezone,
          chatbot_name: chatbotName,
        },
      ])

      if (credentialsError) throw credentialsError

      // Default theme values
      const defaultThemeValues = {
        primaryColor: "#3B82F6", // Default blue color
        secondaryColor: "#10B981", // Default green color
        borderRadius: 8,
        avatarUrl: "/images/default-avatar.png",
        darkMode: false,
        chatbotName: chatbotName || `${firstName}'s Chatbot`,
      }

      // Insert initial theme data with chatbot name
      const { error: themeError } = await supabaseSignup.from("chatbot_themes").insert([
        {
          chatbot_id: chatbotId,
          chatbot_name: chatbotName || `${firstName}'s Chatbot`, // Use provided name or default
          primary_color: defaultThemeValues.primaryColor,
          secondary_color: defaultThemeValues.secondaryColor,
          border_radius: defaultThemeValues.borderRadius,
          dark_mode: defaultThemeValues.darkMode,
        },
      ])

      if (themeError) {
        console.error("Error creating theme:", themeError)
        // Continue anyway as this is not critical for signup
      }

      // Upload avatar if selected
      if (selectedFile) {
        await uploadAvatar(chatbotId)
      }

      // Store username and chatbotId in localStorage for future use
      localStorage.setItem(
        "userData",
        JSON.stringify({
          username,
          chatbotId,
          name: `${firstName} ${lastName}`.trim(),
          email: username,
        }),
      )

      // Store theme in localStorage
      localStorage.setItem("chatbotTheme", JSON.stringify(defaultThemeValues))

      // Apply theme to CSS variables immediately
      if (typeof document !== "undefined") {
        document.documentElement.style.setProperty("--primary-color", defaultThemeValues.primaryColor)
        document.documentElement.style.setProperty("--secondary-color", defaultThemeValues.secondaryColor)
        document.documentElement.style.setProperty("--border-radius", `${defaultThemeValues.borderRadius}px`)

        if (defaultThemeValues.darkMode) {
          document.documentElement.classList.add("dark")
        } else {
          document.documentElement.classList.remove("dark")
        }
      }

      // Dispatch events to notify components
      window.dispatchEvent(new Event("storage"))
      window.dispatchEvent(new CustomEvent("userLoggedIn"))
      window.dispatchEvent(
        new CustomEvent("themeUpdate", {
          detail: defaultThemeValues,
        }),
      )

      // Redirect to plan selection page instead of profile
      router.push("/signup/plan-selection")
    } catch (error) {
      console.error("Sign up error:", error)
      setError("An unexpected error occurred during sign up")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen pt-20">
      <div className="flex flex-col md:flex-row flex-grow">
        <div className="w-full md:w-1/2 p-4 md:p-8 flex items-start justify-center overflow-y-auto">
          <div className="w-full max-w-md space-y-4">
            <Button variant="ghost" onClick={() => router.push("/")} className="mb-2">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
            <div className="space-y-1">
              <h1 className="text-2xl font-bold tracking-tight">Create an account</h1>
              <p className="text-muted-foreground">Sign up to get started with Bot247</p>
            </div>

            <form onSubmit={handleSignUp} className="space-y-4">
              {/* Required Information Section */}
              <div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1 md:col-span-2">
                    <Label htmlFor="email">
                      Email (Username) <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                      placeholder="you@example.com"
                      required
                    />
                    <p className="text-xs text-muted-foreground">Your email address will be used as your username.</p>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="password">
                        Password <span className="text-red-500">*</span>
                      </Label>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <InfoCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent side="right" className="max-w-xs">
                            <p className="font-medium">Password must:</p>
                            <ul className="list-disc pl-4 text-xs mt-1">
                              <li>Be at least 8 characters long</li>
                              <li>Contain at least one uppercase letter</li>
                              <li>Contain at least one lowercase letter</li>
                              <li>Contain at least one number</li>
                              <li>Contain at least one special character</li>
                              <li>Not contain parts of your email address</li>
                            </ul>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="confirm-password">
                      Confirm Password <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="first-name">
                      First Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="first-name"
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="company">
                      Company Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="company"
                      type="text"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="chatbot-name">
                      Chatbot Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="chatbot-name"
                      type="text"
                      value={chatbotName}
                      onChange={(e) => setChatbotName(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                      placeholder="My Assistant"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Optional Information Section */}
              <div>
                <div className="flex items-center justify-between"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="last-name">Last Name</Label>
                    <Input
                      id="last-name"
                      type="text"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      className="bg-blue-50/50 dark:bg-gray-800/50"
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="role">Role</Label>
                    <Select value={role} onValueChange={setRole}>
                      <SelectTrigger className="bg-blue-50/50 dark:bg-gray-800/50">
                        <SelectValue placeholder="Select a role" />
                      </SelectTrigger>
                      <SelectContent>
                        {roleOptions.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1 md:col-span-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select value={timezone} onValueChange={setTimezone}>
                      <SelectTrigger className="bg-blue-50/50 dark:bg-gray-800/50">
                        <SelectValue placeholder="Select a timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        {timezoneOptions.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Avatar Upload - Compact Version */}
                  <div className="space-y-1 md:col-span-2">
                    <Label>Profile Picture</Label>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/*"
                      className="hidden"
                    />

                    <div className="flex items-center gap-4">
                      {previewUrl ? (
                        <div className="relative">
                          <div className="relative w-16 h-16 rounded-full overflow-hidden">
                            <Image
                              src={previewUrl || "/placeholder.svg"}
                              alt="Avatar preview"
                              fill
                              className="object-cover"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={handleRemoveFile}
                            className="absolute -top-1 -right-1 p-1 bg-gray-800 bg-opacity-70 rounded-full text-white hover:bg-opacity-100 transition-opacity"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ) : (
                        <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                          <Upload className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                      <div
                        className="flex-1 border border-gray-300 dark:border-gray-600 rounded-lg p-3 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                        onClick={handleBrowseClick}
                      >
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          <p className="font-medium">Drag and drop or click to browse</p>
                          <p className="text-xs mt-1">PNG, JPG, GIF up to 5MB</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  "Sign Up"
                )}
              </Button>

              <div className="text-center text-sm">
                Already have an account?{" "}
                <Link href="/login" className="text-blue-600 hover:underline dark:text-blue-400">
                  Log In
                </Link>
              </div>

              <div className="text-center text-xs text-muted-foreground">
                By signing up, you agree to Bot247's{" "}
                <Link href="/terms-of-service" className="text-blue-600 hover:underline dark:text-blue-400">
                  Terms of Service
                </Link>{" "}
                and{" "}
                <Link href="/privacy-policy" className="text-blue-600 hover:underline dark:text-blue-400">
                  Privacy Policy
                </Link>
              </div>
            </form>
          </div>
        </div>

        <div className="hidden md:flex w-1/2 bg-gray-50 dark:bg-gray-900 p-8 items-center justify-center">
          <TestimonialCarousel />
        </div>
      </div>
      <Footer />
    </div>
  )
}

// Import the password hashing function
async function hashPassword(password: string): Promise<string> {
  // Call the API route to hash the password
  const response = await fetch("/api/hash-password", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ password }),
  })

  if (!response.ok) {
    throw new Error("Failed to hash password")
  }

  const data = await response.json()
  return data.hashedPassword
}
