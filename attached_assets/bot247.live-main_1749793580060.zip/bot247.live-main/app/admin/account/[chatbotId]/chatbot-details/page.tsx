"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import {
  Palette,
  Settings,
  Save,
  FileText,
  Link2,
  Upload,
  Trash2,
  ImageIcon,
  Plus,
  X,
  Download,
  Loader2,
  Globe,
  BarChart,
  MessageSquare,
} from "lucide-react"
import AccountSidebar from "../components/account-sidebar"
import { toast } from "sonner"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ScrollArea } from "@/components/ui/scroll-area"
import ChatInterface from "@/app/components/chat-interface"
import { logAuditEvent } from "@/app/utils/audit-logger"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Lead {
  id: number
  created_at: string
  chatbot_id: string
  name: string
  email: string
  phone: string
  session_id: string | null
}

export default function ChatbotDetailsPage({ params }: { params: { chatbotId: string } }) {
  const router = useRouter()
  const supabase = createClientComponentClient()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState("appearance")

  // Document management states
  const [documents, setDocuments] = useState<any[]>([])
  const [loadingDocs, setLoadingDocs] = useState(false)
  const [uploadingDoc, setUploadingDoc] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // URL management states
  const [urls, setUrls] = useState<string[]>([])
  const [loadingUrls, setLoadingUrls] = useState(false)
  const [newUrl, setNewUrl] = useState("")
  const [savingUrl, setSavingUrl] = useState(false)

  // Domain management states
  const [domains, setDomains] = useState<string[]>([])
  const [loadingDomains, setLoadingDomains] = useState(false)
  const [newDomain, setNewDomain] = useState("")
  const [savingDomain, setSavingDomain] = useState(false)

  // Avatar management states
  const [avatar, setAvatar] = useState<string | null>(null)
  const [loadingAvatar, setLoadingAvatar] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const avatarInputRef = useRef<HTMLInputElement>(null)

  // Conversation management states
  const [conversations, setConversations] = useState<{ date_of_convo: string; count: number }[]>([])
  const [loadingConversations, setLoadingConversations] = useState(false)
  const [conversationsForDate, setConversationsForDate] = useState<{
    date: string
    conversations: { id: string; created_at: string; messages: { role: "user" | "assistant"; content: string }[] }[]
  } | null>(null)
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null)
  const [selectedMessages, setSelectedMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([])
  const [error, setError] = useState<string | null>(null)

  // Default values
  const defaultTheme = {
    chatbot_id: params.chatbotId,
    primary_color: "#3B82F6",
    secondary_color: "#10B981",
    border_radius: 8,
    dark_mode: false,
    chatbot_name: "AI Assistant",
    greeting: "Hello! How can I help you today?",
    instruction:
      "You are an advanced educational assistant for [Organization/Institute name]. Your goal is to provide personalized, efficient, and engaging assistance to prospective students, guiding them through the admission process, academic programs, campus life, and more. Your tone is friendly, professional, and contextually aware, ensuring that users feel comfortable, respected, and supported throughout their journey",
    response_tone: "Friendly",
    response_length: "Medium",
    pulsating_effect: "yes",
    alignment: "bottom-right",
  }

  const [theme, setTheme] = useState(defaultTheme)

  useEffect(() => {
    async function fetchChatbotTheme() {
      try {
        setLoading(true)
        const { data, error } = await supabase
          .from("chatbot_themes")
          .select("*")
          .eq("chatbot_id", params.chatbotId)
          .single()

        if (error) {
          console.error("Error fetching chatbot theme:", error)
          // Use default values if no data found
          console.log("Using default theme values:", defaultTheme)
          setTheme(defaultTheme)
        } else if (data) {
          // Use fetched data with fallbacks to default values for any missing fields
          // Normalize response_tone to ensure proper capitalization
          const responseTone = data.response_tone
            ? data.response_tone.toLowerCase() === "friendly"
              ? "Friendly"
              : data.response_tone.toLowerCase() === "professional"
                ? "Professional"
                : "Friendly"
            : "Friendly"

          // Normalize response_length to ensure proper capitalization
          const responseLength = data.response_length
            ? data.response_length.toLowerCase() === "concise"
              ? "Concise"
              : data.response_length.toLowerCase() === "detailed"
                ? "Detailed"
                : "Concise"
            : "Concise"

          // Normalize pulsating_effect to ensure proper format
          const pulsatingEffect = data.pulsating_effect
            ? data.pulsating_effect.toLowerCase() === "yes" || data.pulsating_effect.toLowerCase() === "true"
              ? "yes"
              : "no"
            : "yes"

          const themeData = {
            ...data,
            response_tone: responseTone,
            response_length: responseLength,
            pulsating_effect: pulsatingEffect,
          }

          console.log("Fetched theme data with normalized values:", {
            response_tone: themeData.response_tone,
            response_length: themeData.response_length,
            pulsating_effect: themeData.pulsating_effect,
          })

          setTheme(themeData)
        } else {
          console.log("No theme data found, using defaults:", defaultTheme)
          setTheme(defaultTheme)
        }
      } catch (error) {
        console.error("Error:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchChatbotTheme()
  }, [params.chatbotId, supabase])

  // Add this effect right after the fetchChatbotTheme effect
  useEffect(() => {
    // Fetch avatar immediately when component mounts
    const loadAvatar = async () => {
      try {
        setLoadingAvatar(true)
        console.log("Initial avatar fetch for chatbot ID:", params.chatbotId)

        // List files in the chatbotavatar bucket for this chatbot
        const { data: files, error } = await supabase.storage.from("chatbotavatar").list(params.chatbotId)

        if (error) {
          console.error("Error listing avatar files:", error)
          setAvatar(null)
        } else if (files && files.length > 0) {
          console.log("Found avatar files:", files)

          // Find the first image file
          const imageFile = files.find(
            (file) =>
              file.name.endsWith(".jpg") ||
              file.name.endsWith(".jpeg") ||
              file.name.endsWith(".png") ||
              file.name.endsWith(".gif"),
          )

          if (imageFile) {
            // Get the public URL for the image
            const { data: urlData } = supabase.storage
              .from("chatbotavatar")
              .getPublicUrl(`${params.chatbotId}/${imageFile.name}`)

            console.log("Using avatar:", urlData.publicUrl)
            setAvatar(urlData.publicUrl)
          } else {
            console.log("No image files found in the folder")
            setAvatar(null)
          }
        } else {
          console.log("No files found in chatbotavatar bucket for this chatbot")
          setAvatar(null)
        }
      } catch (error) {
        console.error("Error in initial avatar fetch:", error)
        setAvatar(null)
      } finally {
        setLoadingAvatar(false)
      }
    }

    loadAvatar()
  }, [params.chatbotId, supabase])

  // Effect to handle tab changes
  useEffect(() => {
    if (activeTab === "documents") {
      fetchDocuments()
    } else if (activeTab === "urls") {
      fetchUrls()
    } else if (activeTab === "domains") {
      fetchDomains()
    } else if (activeTab === "avatar") {
      fetchAvatar()
    } else if (activeTab === "conversations") {
      fetchConversations()
    }
  }, [activeTab, params.chatbotId])

  // Update selected messages whenever the selected conversation ID changes
  useEffect(() => {
    if (selectedConversationId && conversationsForDate) {
      const selectedConversation = conversationsForDate.conversations.find((conv) => conv.id === selectedConversationId)
      if (selectedConversation && selectedConversation.messages) {
        console.log("Setting selected messages:", selectedConversation.messages.length)
        setSelectedMessages(selectedConversation.messages)
      } else {
        console.log("No messages found for this conversation")
        setSelectedMessages([])
      }
    } else {
      setSelectedMessages([])
    }
  }, [selectedConversationId, conversationsForDate])

  // Fetch documents from Supabase storage
  const fetchDocuments = async () => {
    try {
      setLoadingDocs(true)

      // List files in the documentuploaded bucket for this chatbot
      const { data, error } = await supabase.storage.from("documentuploaded").list(params.chatbotId, {
        sortBy: { column: "name", order: "asc" },
      })

      if (error) {
        console.error("Error fetching documents:", error)
        toast.error("Failed to load documents")
        setDocuments([])
      } else {
        setDocuments(data || [])
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred while loading documents")
    } finally {
      setLoadingDocs(false)
    }
  }

  // Fetch URLs from Supabase database
  const fetchUrls = async () => {
    try {
      setLoadingUrls(true)

      // Get URLs from the urls_uploaded table
      const { data, error } = await supabase
        .from("urls_uploaded")
        .select("url_links")
        .eq("chatbot_id", params.chatbotId)
        .single()

      if (error) {
        if (error.code === "PGRST116") {
          // No record found, set empty array
          setUrls([])
        } else {
          console.error("Error fetching URLs:", error)
          toast.error("Failed to load URLs")
          setUrls([])
        }
      } else if (data && data.url_links && data.url_links.links) {
        setUrls(data.url_links.links)
      } else {
        setUrls([])
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred while loading URLs")
    } finally {
      setLoadingUrls(false)
    }
  }

  // Fetch domains from Supabase database
  const fetchDomains = async () => {
    try {
      setLoadingDomains(true)

      // Get domains from the embed_domains table
      const { data, error } = await supabase
        .from("embed_domains")
        .select("domains")
        .eq("chatbot_id", params.chatbotId)
        .single()

      if (error) {
        if (error.code === "PGRST116") {
          // No record found, set empty array
          setDomains([])
        } else {
          console.error("Error fetching domains:", error)
          toast.error("Failed to load domains")
          setDomains([])
        }
      } else if (data && data.domains && data.domains.links) {
        setDomains(data.domains.links)
      } else {
        setDomains([])
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred while loading domains")
    } finally {
      setLoadingDomains(false)
    }
  }

  // Fetch avatar from Supabase storage - this is called when the avatar tab is selected
  const fetchAvatar = async () => {
    try {
      setLoadingAvatar(true)
      console.log("Fetching avatar for chatbot ID:", params.chatbotId)

      // List files in the chatbotavatar bucket for this chatbot
      const { data: files, error } = await supabase.storage.from("chatbotavatar").list(params.chatbotId)

      if (error) {
        console.error("Error listing avatar files:", error)
        toast.error("Failed to load avatar")
        setAvatar(null)
      } else if (files && files.length > 0) {
        console.log("Found avatar files:", files)

        // Find the first image file
        const imageFile = files.find(
          (file) =>
            file.name.endsWith(".jpg") ||
            file.name.endsWith(".jpeg") ||
            file.name.endsWith(".png") ||
            file.name.endsWith(".gif"),
        )

        if (imageFile) {
          // Get the public URL for the image
          const { data: urlData } = supabase.storage
            .from("chatbotavatar")
            .getPublicUrl(`${params.chatbotId}/${imageFile.name}`)

          console.log("Using avatar:", urlData.publicUrl)
          setAvatar(urlData.publicUrl)
        } else {
          console.log("No image files found in the folder")
          setAvatar(null)
        }
      } else {
        console.log("No files found in chatbotavatar bucket for this chatbot")
        setAvatar(null)
      }
    } catch (error) {
      console.error("Error in fetchAvatar:", error)
      toast.error("An unexpected error occurred while loading avatar")
    } finally {
      setLoadingAvatar(false)
    }
  }

  // Fetch conversations with pagination
  const fetchConversations = async () => {
    if (!params.chatbotId) return

    setLoadingConversations(true)
    setError(null)

    try {
      let allDates = []
      let hasMore = true
      let page = 0
      const pageSize = 1000 // Supabase's maximum limit

      // Fetch all conversation dates using pagination
      while (hasMore) {
        const { data, error: fetchError } = await supabase
          .from("testing_zaps2")
          .select("date_of_convo")
          .eq("chatbot_id", params.chatbotId)
          .range(page * pageSize, (page + 1) * pageSize - 1)
          .order("date_of_convo", { ascending: false })

        if (fetchError) throw fetchError

        if (data && data.length > 0) {
          allDates = [...allDates, ...data]
          // Check if we need to fetch more
          hasMore = data.length === pageSize
          page++
        } else {
          hasMore = false
        }
      }

      if (allDates.length > 0) {
        // Group by date and count occurrences
        const dateMap = new Map<string, number>()
        allDates.forEach((item) => {
          const date = item.date_of_convo
          dateMap.set(date, (dateMap.get(date) || 0) + 1)
        })

        // Convert to array of objects
        const conversationSummary = Array.from(dateMap.entries()).map(([date, count]) => ({
          date_of_convo: date,
          count,
        }))

        setConversations(conversationSummary)
      } else {
        setConversations([])
      }
    } catch (error) {
      console.error("Error fetching conversations:", error)
      setError(error instanceof Error ? error.message : "Failed to fetch conversations")
    } finally {
      setLoadingConversations(false)
    }
  }

  // Fetch conversations for a specific date with pagination
  const fetchConversationsForDate = async (date: string) => {
    if (!params.chatbotId) return null

    try {
      let allConversations = []
      let hasMore = true
      let page = 0
      const pageSize = 1000 // Supabase's maximum limit

      while (hasMore) {
        const { data, error } = await supabase
          .from("testing_zaps2")
          .select("id, messages, created_at")
          .eq("chatbot_id", params.chatbotId)
          .eq("date_of_convo", date)
          .range(page * pageSize, (page + 1) * pageSize - 1)
          .order("created_at", { ascending: false })

        if (error) throw error

        if (data && data.length > 0) {
          allConversations = [...allConversations, ...data]
          // Check if we need to fetch more
          hasMore = data.length === pageSize
          page++
        } else {
          hasMore = false
        }
      }

      if (allConversations.length > 0) {
        console.log("Fetched conversations for date:", date, allConversations.length)

        // Process the data to ensure messages are properly formatted
        const processedData = allConversations.map((item) => ({
          id: item.id,
          created_at: item.created_at,
          messages: Array.isArray(item.messages) ? item.messages : [],
        }))

        setConversationsForDate({
          date,
          conversations: processedData,
        })

        // Select the first conversation by default and set its messages
        setSelectedConversationId(processedData[0].id)
        setSelectedMessages(processedData[0].messages || [])

        return allConversations
      }

      return allConversations
    } catch (error) {
      console.error("Error fetching conversations for date:", error)
      return null
    }
  }

  // Handle conversation selection
  const handleConversationSelect = async (conversationId: string) => {
    console.log("Selecting conversation:", conversationId)
    setSelectedConversationId(conversationId)

    try {
      // Fetch the specific conversation by ID directly from the database
      const { data, error } = await supabase.from("testing_zaps2").select("messages").eq("id", conversationId).single()

      if (error) {
        console.error("Error fetching conversation messages:", error)
        setSelectedMessages([])
        return
      }

      if (data && data.messages) {
        console.log("Found messages:", data.messages.length)
        setSelectedMessages(data.messages)
      } else {
        console.log("No messages found for this conversation")
        setSelectedMessages([])
      }
    } catch (error) {
      console.error("Error in handleConversationSelect:", error)
      setSelectedMessages([])
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setTheme((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (checked: boolean) => {
    setTheme((prev) => ({ ...prev, dark_mode: checked }))
  }

  const handleSliderChange = (value: number[]) => {
    setTheme((prev) => ({ ...prev, border_radius: value[0] }))
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
  }

  const handleSave = async () => {
    try {
      setSaving(true)

      // Store original theme for audit logging
      const originalTheme = { ...theme }

      console.log("Saving theme values:", {
        response_tone: theme.response_tone,
        response_length: theme.response_length,
        pulsating_effect: theme.pulsating_effect,
      })

      // Check if record exists
      const { data: existingData, error: checkError } = await supabase
        .from("chatbot_themes")
        .select("*")
        .eq("chatbot_id", params.chatbotId)
        .single()

      let saveError

      if (checkError && checkError.code === "PGRST116") {
        // Record doesn't exist, insert new record
        const { error } = await supabase.from("chatbot_themes").insert({
          chatbot_id: params.chatbotId,
          primary_color: theme.primary_color,
          secondary_color: theme.secondary_color,
          border_radius: theme.border_radius,
          dark_mode: theme.dark_mode,
          chatbot_name: theme.chatbot_name,
          greeting: theme.greeting,
          instruction: theme.instruction,
          response_tone: theme.response_tone,
          response_length: theme.response_length,
          pulsating_effect: theme.pulsating_effect,
          // Remove this line
          // alignment: theme.alignment,
        })
        saveError = error

        // Log creation as a change
        if (!error) {
          const changes: Record<string, { previous: any; current: any }> = {
            action: { previous: "none", current: "created_new_theme" },
            chatbot_name: { previous: null, current: theme.chatbot_name },
            primary_color: { previous: null, current: theme.primary_color },
            secondary_color: { previous: null, current: theme.secondary_color },
            border_radius: { previous: null, current: theme.border_radius },
            dark_mode: { previous: null, current: theme.dark_mode },
            greeting: { previous: null, current: theme.greeting },
            instruction: { previous: null, current: theme.instruction },
            response_tone: { previous: null, current: theme.response_tone },
            response_length: { previous: null, current: theme.response_length },
            pulsating_effect: { previous: null, current: theme.pulsating_effect },
            // alignment: { previous: null, current: theme.alignment },
          }
          await logAuditEvent(params.chatbotId, "admin", changes)
        }
      } else {
        // Record exists, update it
        const { error } = await supabase
          .from("chatbot_themes")
          .update({
            primary_color: theme.primary_color,
            secondary_color: theme.secondary_color,
            border_radius: theme.border_radius,
            dark_mode: theme.dark_mode,
            chatbot_name: theme.chatbot_name,
            greeting: theme.greeting,
            instruction: theme.instruction,
            response_tone: theme.response_tone,
            response_length: theme.response_length,
            pulsating_effect: theme.pulsating_effect,
            // Remove this line
            // alignment: theme.alignment,
          })
          .eq("chatbot_id", params.chatbotId)
        saveError = error

        // Log changes for audit
        if (!error && existingData) {
          const changes: Record<string, { previous: any; current: any }> = {}

          // Only log fields that actually changed
          if (existingData.primary_color !== theme.primary_color) {
            changes.primary_color = { previous: existingData.primary_color, current: theme.primary_color }
          }
          if (existingData.secondary_color !== theme.secondary_color) {
            changes.secondary_color = { previous: existingData.secondary_color, current: theme.secondary_color }
          }
          if (existingData.border_radius !== theme.border_radius) {
            changes.border_radius = { previous: existingData.border_radius, current: theme.border_radius }
          }
          if (existingData.dark_mode !== theme.dark_mode) {
            changes.dark_mode = { previous: existingData.dark_mode, current: theme.dark_mode }
          }
          if (existingData.chatbot_name !== theme.chatbot_name) {
            changes.chatbot_name = { previous: existingData.chatbot_name, current: theme.chatbot_name }
          }
          if (existingData.greeting !== theme.greeting) {
            changes.greeting = { previous: existingData.greeting, current: theme.greeting }
          }
          if (existingData.instruction !== theme.instruction) {
            changes.instruction = { previous: existingData.instruction, current: theme.instruction }
          }
          if (existingData.response_tone !== theme.response_tone) {
            changes.response_tone = { previous: existingData.response_tone, current: theme.response_tone }
          }
          if (existingData.response_length !== theme.response_length) {
            changes.response_length = { previous: existingData.response_length, current: theme.response_length }
          }
          if (existingData.pulsating_effect !== theme.pulsating_effect) {
            changes.pulsating_effect = { previous: existingData.pulsating_effect, current: theme.pulsating_effect }
          }
          // Remove this block
          // if (existingData.alignment !== theme.alignment) {
          //   changes.alignment = { previous: existingData.alignment, current: theme.alignment }
          // }

          // Only log if there were actual changes
          if (Object.keys(changes).length > 0) {
            await logAuditEvent(params.chatbotId, "admin", changes)
          }
        }
      }

      if (saveError) {
        console.error("Error saving chatbot theme:", saveError)
        toast.error("Failed to save changes")
      } else {
        toast.success("Changes saved successfully")

        // Fetch the latest avatar to reflect any changes
        await fetchAvatar()

        // Force reload the page to refresh the chatbot with new settings
        window.location.reload()
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    } finally {
      setSaving(false)
    }
  }

  // Handle document upload
  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      return
    }

    try {
      setUploadingDoc(true)

      // Check if folder exists, if not it will be created automatically
      const files = Array.from(e.target.files)
      const uploadedFiles = []

      for (const file of files) {
        const filePath = `${params.chatbotId}/${file.name}`

        // Upload the file
        const { error: uploadError } = await supabase.storage.from("documentuploaded").upload(filePath, file, {
          cacheControl: "3600",
          upsert: true,
        })

        if (uploadError) {
          console.error("Error uploading document:", uploadError)
          toast.error(`Failed to upload ${file.name}`)
        } else {
          uploadedFiles.push(file.name)
        }
      }

      // Log the document uploads
      if (uploadedFiles.length > 0) {
        const changes = {
          action: { previous: "no_documents", current: "documents_uploaded" },
          uploaded_files: { previous: null, current: uploadedFiles },
        }
        await logAuditEvent(params.chatbotId, "admin", changes)
      }

      // Refresh the document list
      await fetchDocuments()
      toast.success("Documents uploaded successfully")
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred during upload")
    } finally {
      setUploadingDoc(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  // Handle document deletion
  const handleDocumentDelete = async (fileName: string) => {
    try {
      const filePath = `${params.chatbotId}/${fileName}`

      // Delete the file
      const { error } = await supabase.storage.from("documentuploaded").remove([filePath])

      if (error) {
        console.error("Error deleting document:", error)
        toast.error("Failed to delete document")
      } else {
        // Log the document deletion
        const changes = {
          action: { previous: "document_existed", current: "document_deleted" },
          deleted_file: { previous: fileName, current: null },
        }
        await logAuditEvent(params.chatbotId, "admin", changes)

        // Refresh the document list
        await fetchDocuments()
        toast.success("Document deleted successfully")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred during deletion")
    } finally {
      setUploadingDoc(false)
    }
  }

  // Handle document download
  const handleDocumentDownload = async (fileName: string) => {
    try {
      const filePath = `${params.chatbotId}/${fileName}`

      // Get the download URL
      const { data, error } = await supabase.storage.from("documentuploaded").createSignedUrl(filePath, 60) // 60 seconds expiry

      if (error) {
        console.error("Error generating download URL:", error)
        toast.error("Failed to generate download link")
      } else if (data) {
        // Open the download URL in a new tab
        window.open(data.signedUrl, "_blank")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    }
  }

  // Handle URL addition
  const handleAddUrl = async () => {
    if (!newUrl.trim()) {
      toast.error("Please enter a valid URL")
      return
    }

    try {
      setSavingUrl(true)

      // Validate URL format
      try {
        new URL(newUrl) // This will throw an error if the URL is invalid
      } catch (e) {
        toast.error("Please enter a valid URL with http:// or https://")
        setSavingUrl(false)
        return
      }

      // Check if URL already exists
      if (urls.includes(newUrl)) {
        toast.error("This URL already exists")
        setSavingUrl(false)
        return
      }

      // Add the new URL to the list
      const updatedUrls = [...urls, newUrl]

      // Check if a record already exists
      const { data, error: checkError } = await supabase
        .from("urls_uploaded")
        .select("id")
        .eq("chatbot_id", params.chatbotId)
        .single()

      if (checkError && checkError.code === "PGRST116") {
        // No record exists, create a new one
        const { error } = await supabase.from("urls_uploaded").insert({
          chatbot_id: params.chatbotId,
          url_links: { links: updatedUrls },
          created_at: new Date().toISOString(),
        })

        if (error) {
          console.error("Error adding URL:", error)
          toast.error("Failed to add URL")
        } else {
          // Log the URL addition
          const changes = {
            action: { previous: "no_urls", current: "url_added" },
            urls: { previous: urls, current: updatedUrls },
          }
          await logAuditEvent(params.chatbotId, "admin", changes)

          setUrls(updatedUrls)
          setNewUrl("")
          toast.success("URL added successfully")
        }
      } else {
        // Record exists, update it
        const { error } = await supabase
          .from("urls_uploaded")
          .update({
            url_links: { links: updatedUrls },
          })
          .eq("chatbot_id", params.chatbotId)

        if (error) {
          console.error("Error adding URL:", error)
          toast.error("Failed to add URL")
        } else {
          // Log the URL addition
          const changes = {
            action: { previous: "url_list_updated", current: "url_added" },
            added_url: { previous: null, current: newUrl },
          }
          await logAuditEvent(params.chatbotId, "admin", changes)

          setUrls(updatedUrls)
          setNewUrl("")
          toast.success("URL added successfully")
        }
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    } finally {
      setSavingUrl(false)
    }
  }

  // Handle URL deletion
  const handleDeleteUrl = async (urlToDelete: string) => {
    try {
      setSavingUrl(true)

      // Remove the URL from the list
      const updatedUrls = urls.filter((url) => url !== urlToDelete)

      // Update the record
      const { error } = await supabase
        .from("urls_uploaded")
        .update({
          url_links: { links: updatedUrls },
        })
        .eq("chatbot_id", params.chatbotId)

      if (error) {
        console.error("Error deleting URL:", error)
        toast.error("Failed to delete URL")
      } else {
        // Log the URL deletion
        const changes = {
          action: { previous: "url_existed", current: "url_deleted" },
          deleted_url: { previous: urlToDelete, current: null },
        }
        await logAuditEvent(params.chatbotId, "admin", changes)

        setUrls(updatedUrls)
        toast.success("URL deleted successfully")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    } finally {
      setSavingUrl(false)
    }
  }

  // Handle domain addition
  const handleAddDomain = async () => {
    if (!newDomain.trim()) {
      toast.error("Please enter a valid domain")
      return
    }

    try {
      setSavingDomain(true)

      // Validate domain format
      try {
        new URL(newDomain) // This will throw an error if the URL is invalid
      } catch (e) {
        toast.error("Please enter a valid domain with http:// or https://")
        setSavingDomain(false)
        return
      }

      // Check if domain already exists
      if (domains.includes(newDomain)) {
        toast.error("This domain already exists")
        setSavingDomain(false)
        return
      }

      // Add the new domain to the list
      const updatedDomains = [...domains, newDomain]

      // Check if a record already exists
      const { data, error: checkError } = await supabase
        .from("embed_domains")
        .select("id")
        .eq("chatbot_id", params.chatbotId)
        .single()

      if (checkError && checkError.code === "PGRST116") {
        // No record exists, create a new one
        const { error } = await supabase.from("embed_domains").insert({
          chatbot_id: params.chatbotId,
          domains: { links: updatedDomains },
          created_at: new Date().toISOString(),
        })

        if (error) {
          console.error("Error adding domain:", error)
          toast.error("Failed to add domain")
        } else {
          // Log the domain addition
          const changes = {
            action: { previous: "no_domains", current: "domain_added" },
            domains: { previous: domains, current: updatedDomains },
          }
          await logAuditEvent(params.chatbotId, "admin", changes)

          setDomains(updatedDomains)
          setNewDomain("")
          toast.success("Domain added successfully")
        }
      } else {
        // Record exists, update it
        const { error } = await supabase
          .from("embed_domains")
          .update({
            domains: { links: updatedDomains },
          })
          .eq("chatbot_id", params.chatbotId)

        if (error) {
          console.error("Error adding domain:", error)
          toast.error("Failed to add domain")
        } else {
          // Log the domain addition
          const changes = {
            action: { previous: "domain_list_updated", current: "domain_added" },
            added_domain: { previous: null, current: newDomain },
          }
          await logAuditEvent(params.chatbotId, "admin", changes)

          setDomains(updatedDomains)
          setNewDomain("")
          toast.success("Domain added successfully")
        }
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    } finally {
      setSavingDomain(false)
    }
  }

  // Handle domain deletion
  const handleDeleteDomain = async (domainToDelete: string) => {
    try {
      setSavingDomain(true)

      // Remove the domain from the list
      const updatedDomains = domains.filter((domain) => domain !== domainToDelete)

      // Update the record
      const { error } = await supabase
        .from("embed_domains")
        .update({
          domains: { links: updatedDomains },
        })
        .eq("chatbot_id", params.chatbotId)

      if (error) {
        console.error("Error deleting domain:", error)
        toast.error("Failed to delete domain")
      } else {
        // Log the domain deletion
        const changes = {
          action: { previous: "domain_existed", current: "domain_deleted" },
          deleted_domain: { previous: domainToDelete, current: null },
        }
        await logAuditEvent(params.chatbotId, "admin", changes)

        setDomains(updatedDomains)
        toast.success("Domain deleted successfully")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    } finally {
      setSavingDomain(false)
    }
  }

  // Handle avatar upload
  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      return
    }

    try {
      setUploadingAvatar(true)
      const file = e.target.files[0]
      const previousAvatar = avatar

      // First, check if there are any existing files and delete them
      const { data: existingFiles, error: listError } = await supabase.storage
        .from("chatbotavatar")
        .list(params.chatbotId)

      if (listError) {
        console.error("Error listing existing avatar files:", listError)
      } else if (existingFiles && existingFiles.length > 0) {
        // Delete existing files
        const filesToDelete = existingFiles.map((file) => `${params.chatbotId}/${file.name}`)
        const { error: deleteError } = await supabase.storage.from("chatbotavatar").remove(filesToDelete)

        if (deleteError) {
          console.error("Error deleting existing avatar files:", deleteError)
        }
      }

      // Upload the new file
      const fileName = `avatar-${Date.now()}.${file.name.split(".").pop()}`
      const filePath = `${params.chatbotId}/${fileName}`

      const { error: uploadError } = await supabase.storage.from("chatbotavatar").upload(filePath, file, {
        cacheControl: "3600",
        upsert: true,
      })

      if (uploadError) {
        console.error("Error uploading avatar:", uploadError)
        toast.error("Failed to upload avatar")
      } else {
        // Get the public URL
        const { data: urlData } = supabase.storage.from("chatbotavatar").getPublicUrl(filePath)

        // Log the avatar change
        const changes = {
          action: { previous: previousAvatar ? "avatar_replaced" : "avatar_added", current: "new_avatar_uploaded" },
          avatar_url: { previous: previousAvatar, current: urlData.publicUrl },
        }
        await logAuditEvent(params.chatbotId, "admin", changes)

        console.log("Avatar uploaded successfully, new URL:", urlData.publicUrl)
        setAvatar(urlData.publicUrl)
        toast.success("Avatar uploaded successfully")
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred during upload")
    } finally {
      setUploadingAvatar(false)
      if (avatarInputRef.current) {
        avatarInputRef.current.value = ""
      }
    }
  }

  // Handle avatar deletion
  const handleAvatarDelete = async () => {
    try {
      setUploadingAvatar(true)
      const previousAvatar = avatar

      // List files in the chatbotavatar bucket for this chatbot
      const { data, error: listError } = await supabase.storage.from("chatbotavatar").list(params.chatbotId)

      if (listError) {
        console.error("Error listing avatar files:", listError)
        toast.error("Failed to list avatar files")
      } else if (data && data.length > 0) {
        // Delete all files
        const filesToDelete = data.map((file) => `${params.chatbotId}/${file.name}`)
        const { error: deleteError } = await supabase.storage.from("chatbotavatar").remove(filesToDelete)

        if (deleteError) {
          console.error("Error deleting avatar files:", deleteError)
          toast.error("Failed to delete avatar")
        } else {
          // Log the avatar deletion
          const changes = {
            action: { previous: "avatar_existed", current: "avatar_deleted" },
            deleted_avatar: { previous: previousAvatar, current: null },
          }
          await logAuditEvent(params.chatbotId, "admin", changes)

          setAvatar(null)
          toast.success("Avatar deleted successfully")
        }
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred")
    } finally {
      setUploadingAvatar(false)
    }
  }

  // Handle back to profile
  const handleBackToProfile = () => {
    router.push(`/admin/account/${params.chatbotId}`)
  }

  // Fetch leads
  const [leads, setLeads] = useState<Lead[]>([])
  const [loadingLeads, setLoadingLeads] = useState(false)

  const fetchLeads = async () => {
    try {
      setLoadingLeads(true)
      const { data, error } = await supabase
        .from("collected_leads")
        .select("*")
        .eq("chatbot_id", params.chatbotId)
        .or("email.neq.000,phone.neq.000")
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching leads:", error)
        toast.error("Failed to load leads")
        setLeads([])
      } else {
        setLeads(data || [])
      }
    } catch (error) {
      console.error("Error:", error)
      toast.error("An unexpected error occurred while loading leads")
    } finally {
      setLoadingLeads(false)
    }
  }

  return (
    <div className="container mx-auto py-24">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Sidebar */}
        <div className="md:col-span-2">
          <AccountSidebar activePage="chatbot-details" chatbotId={params.chatbotId} />
        </div>

        {/* Main Content */}
        <div className="md:col-span-8">
          <Card className="shadow-sm">
            <CardContent className="pt-8 px-8">
              {/* Save Changes button at the top left */}
              <div className="flex justify-start mb-8">
                <Button onClick={handleSave} disabled={saving || loading} className="flex items-center gap-2">
                  {saving ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
              </div>

              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
                </div>
              ) : (
                <Tabs defaultValue="appearance" onValueChange={handleTabChange}>
                  <TabsList className="mb-8 flex overflow-x-auto whitespace-nowrap gap-1 pb-2 w-full">
                    <TabsTrigger value="appearance" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <Palette className="h-4 w-4" />
                      Appearance
                    </TabsTrigger>
                    <TabsTrigger value="behavior" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <Settings className="h-4 w-4" />
                      Behavior
                    </TabsTrigger>
                    <TabsTrigger value="documents" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <FileText className="h-4 w-4" />
                      Documents
                    </TabsTrigger>
                    <TabsTrigger value="urls" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <Link2 className="h-4 w-4" />
                      URLs
                    </TabsTrigger>
                    <TabsTrigger value="domains" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <Globe className="h-4 w-4" />
                      Domains
                    </TabsTrigger>
                    <TabsTrigger value="avatar" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <ImageIcon className="h-4 w-4" />
                      Avatar
                    </TabsTrigger>
                    <TabsTrigger value="conversations" className="flex items-center gap-1 px-2 py-1 text-sm">
                      <MessageSquare className="h-4 w-4" />
                      Conversations
                    </TabsTrigger>
                    <TabsTrigger
                      value="analytics"
                      className="flex items-center gap-1 px-2 py-1 text-sm"
                      onClick={() => router.push(`/admin/dashboard/${params.chatbotId}/chatbot-insights`)}
                    >
                      <BarChart className="h-4 w-4" />
                      Analytics
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="appearance">
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="chatbot_name">Chatbot Name</Label>
                        <Input
                          id="chatbot_name"
                          name="chatbot_name"
                          value={theme.chatbot_name}
                          onChange={handleInputChange}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="primary_color">Primary Color</Label>
                        <div className="flex gap-3">
                          <div
                            className="w-10 h-10 rounded-md border"
                            style={{ backgroundColor: theme.primary_color }}
                          />
                          <Input
                            id="primary_color"
                            name="primary_color"
                            type="color"
                            value={theme.primary_color}
                            onChange={handleInputChange}
                            className="w-full"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="secondary_color">Secondary Color</Label>
                        <div className="flex gap-3">
                          <div
                            className="w-10 h-10 rounded-md border"
                            style={{ backgroundColor: theme.secondary_color }}
                          />
                          <Input
                            id="secondary_color"
                            name="secondary_color"
                            type="color"
                            value={theme.secondary_color}
                            onChange={handleInputChange}
                            className="w-full"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="border_radius">Border Radius: {theme.border_radius}px</Label>
                        <Slider
                          id="border_radius"
                          min={0}
                          max={20}
                          step={1}
                          value={[theme.border_radius]}
                          onValueChange={handleSliderChange}
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="behavior">
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="greeting">Greeting Message</Label>
                        <Textarea
                          id="greeting"
                          name="greeting"
                          value={theme.greeting}
                          onChange={handleInputChange}
                          rows={2}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="instruction">Instructions</Label>
                        <Textarea
                          id="instruction"
                          name="instruction"
                          value={theme.instruction}
                          onChange={handleInputChange}
                          rows={6}
                        />
                        <p className="text-sm text-gray-500">
                          These instructions guide how the AI responds to user queries.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="response_tone">Response Tone</Label>
                          <Select
                            value={theme.response_tone || "Friendly"}
                            onValueChange={(value) => setTheme({ ...theme, response_tone: value })}
                          >
                            <SelectTrigger id="response_tone">
                              <SelectValue placeholder="Select tone" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Friendly">Friendly</SelectItem>
                              <SelectItem value="Professional">Professional</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="response_length">Response Length</Label>
                          <Select
                            value={theme.response_length || "Concise"}
                            onValueChange={(value) => setTheme({ ...theme, response_length: value })}
                          >
                            <SelectTrigger id="response_length">
                              <SelectValue placeholder="Select length" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Concise">Concise</SelectItem>
                              <SelectItem value="Detailed">Detailed</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="pulsating_effect">Pulsating Effect</Label>
                          <Select
                            value={theme.pulsating_effect || "yes"}
                            onValueChange={(value) => setTheme({ ...theme, pulsating_effect: value })}
                          >
                            <SelectTrigger id="pulsating_effect">
                              <SelectValue placeholder="Select effect" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="yes">Yes</SelectItem>
                              <SelectItem value="no">No</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="documents">
                    <div className="space-y-6">
                      <div className="flex justify-between items-center">
                        <h3 className="text-lg font-medium">Chatbot Documents</h3>
                        <div className="relative">
                          <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleDocumentUpload}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                            multiple
                            disabled={uploadingDoc}
                          />
                          <Button variant="outline" className="flex items-center gap-2" disabled={uploadingDoc}>
                            {uploadingDoc ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Uploading...
                              </>
                            ) : (
                              <>
                                <Upload className="h-4 w-4" />
                                Upload Documents
                              </>
                            )}
                          </Button>
                        </div>
                      </div>

                      {loadingDocs ? (
                        <div className="flex justify-center items-center h-40">
                          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                        </div>
                      ) : documents.length === 0 ? (
                        <div className="text-center py-8 border rounded-lg bg-gray-50 dark:bg-gray-900">
                          <FileText className="h-12 w-12 mx-auto text-gray-400" />
                          <p className="mt-2 text-gray-500">No documents found</p>
                          <p className="text-sm text-gray-400">Upload documents to enhance your chatbot's knowledge</p>
                        </div>
                      ) : (
                        <div className="border rounded-lg overflow-hidden">
                          <div className="bg-gray-50 dark:bg-gray-900 p-3 border-b font-medium flex items-center">
                            <span className="flex-1">Document Name</span>
                            <span className="w-24 text-center">Size</span>
                            <span className="w-32 text-center">Actions</span>
                          </div>
                          <ScrollArea className="h-[400px]">
                            {documents.map((doc) => (
                              <div
                                key={doc.id}
                                className="flex items-center p-3 border-b last:border-0 hover:bg-gray-50 dark:hover:bg-gray-900"
                              >
                                <div className="flex-1 truncate">
                                  <span className="font-medium">{doc.name}</span>
                                </div>
                                <div className="w-24 text-center text-sm text-gray-500">
                                  {(doc.metadata?.size / 1024).toFixed(2)} KB
                                </div>
                                <div className="w-32 flex justify-center gap-2">
                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          onClick={() => handleDocumentDownload(doc.name)}
                                        >
                                          <Download className="h-4 w-4" />
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <p>Download</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>

                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                          onClick={() => handleDocumentDelete(doc.name)}
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <p>Delete</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                </div>
                              </div>
                            ))}
                          </ScrollArea>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="urls">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Chatbot URLs</h3>
                        <div className="flex gap-2 mb-6">
                          <Input
                            placeholder="Enter URL (e.g., https://example.com)"
                            value={newUrl}
                            onChange={(e) => setNewUrl(e.target.value)}
                            disabled={savingUrl}
                          />
                          <Button
                            onClick={handleAddUrl}
                            disabled={savingUrl || !newUrl.trim()}
                            className="flex items-center gap-2 whitespace-nowrap"
                          >
                            {savingUrl ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Adding...
                              </>
                            ) : (
                              <>
                                <Plus className="h-4 w-4" />
                                Add URL
                              </>
                            )}
                          </Button>
                        </div>
                      </div>

                      {loadingUrls ? (
                        <div className="flex justify-center items-center h-40">
                          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                        </div>
                      ) : urls.length === 0 ? (
                        <div className="text-center py-8 border rounded-lg bg-gray-50 dark:bg-gray-900">
                          <Link2 className="h-12 w-12 mx-auto text-gray-400" />
                          <p className="mt-2 text-gray-500">No URLs found</p>
                          <p className="text-sm text-gray-400">Add URLs to enhance your chatbot's knowledge</p>
                        </div>
                      ) : (
                        <div className="border rounded-lg overflow-hidden">
                          <div className="bg-gray-50 dark:bg-gray-900 p-3 border-b font-medium">URLs</div>
                          <ScrollArea className="h-[400px]">
                            {urls.map((url, index) => (
                              <div
                                key={index}
                                className="flex items-center p-3 border-b last:border-0 hover:bg-gray-50 dark:hover:bg-gray-900"
                              >
                                <div className="flex-1 truncate">
                                  <a
                                    href={url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-500 hover:underline"
                                  >
                                    {url}
                                  </a>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50 ml-2"
                                  onClick={() => handleDeleteUrl(url)}
                                  disabled={savingUrl}
                                >
                                  {savingUrl ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-4 w-4" />}
                                </Button>
                              </div>
                            ))}
                          </ScrollArea>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="domains">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Allowed Embed Domains</h3>
                        <p className="text-sm text-gray-500 mb-4">
                          Add domains where this chatbot is allowed to be embedded. Only websites with these domains
                          will be able to use your chatbot.
                        </p>
                        <div className="flex gap-2 mb-6">
                          <Input
                            placeholder="Enter domain (e.g., https://example.com)"
                            value={newDomain}
                            onChange={(e) => setNewDomain(e.target.value)}
                            disabled={savingDomain}
                          />
                          <Button
                            onClick={handleAddDomain}
                            disabled={savingDomain || !newDomain.trim()}
                            className="flex items-center gap-2 whitespace-nowrap"
                          >
                            {savingDomain ? (
                              <>
                                <Loader2 className="h-4 w-4 animate-spin" />
                                Adding...
                              </>
                            ) : (
                              <>
                                <Plus className="h-4 w-4" />
                                Add Domain
                              </>
                            )}
                          </Button>
                        </div>
                      </div>

                      {loadingDomains ? (
                        <div className="flex justify-center items-center h-40">
                          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                        </div>
                      ) : domains.length === 0 ? (
                        <div className="text-center py-8 border rounded-lg bg-gray-50 dark:bg-gray-900">
                          <Globe className="h-12 w-12 mx-auto text-gray-400" />
                          <p className="mt-2 text-gray-500">No domains found</p>
                          <p className="text-sm text-gray-400">
                            Add domains where your chatbot is allowed to be embedded
                          </p>
                        </div>
                      ) : (
                        <div className="border rounded-lg overflow-hidden">
                          <div className="bg-gray-50 dark:bg-gray-900 p-3 border-b font-medium">Allowed Domains</div>
                          <ScrollArea className="h-[400px]">
                            {domains.map((domain, index) => (
                              <div
                                key={index}
                                className="flex items-center p-3 border-b last:border-0 hover:bg-gray-50 dark:hover:bg-gray-900"
                              >
                                <div className="flex-1 truncate">
                                  <a
                                    href={domain}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-500 hover:underline"
                                  >
                                    {domain}
                                  </a>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50 ml-2"
                                  onClick={() => handleDeleteDomain(domain)}
                                  disabled={savingDomain}
                                >
                                  {savingDomain ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <X className="h-4 w-4" />
                                  )}
                                </Button>
                              </div>
                            ))}
                          </ScrollArea>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="avatar">
                    <div className="space-y-6">
                      <h3 className="text-lg font-medium">Chatbot Avatar</h3>

                      {loadingAvatar ? (
                        <div className="flex justify-center items-center h-40">
                          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center p-6 border rounded-lg bg-gray-50 dark:bg-gray-900">
                          {avatar ? (
                            <div className="text-center">
                              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-lg mx-auto mb-4">
                                <img
                                  src={avatar || "/placeholder.svg"}
                                  alt="Chatbot Avatar"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <p className="text-sm text-gray-500 mb-4">Current avatar</p>
                            </div>
                          ) : (
                            <div className="text-center mb-6">
                              <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center mx-auto mb-4">
                                <ImageIcon className="h-12 w-12 text-gray-400" />
                              </div>
                              <p className="text-gray-500">No avatar uploaded</p>
                            </div>
                          )}

                          <div className="flex gap-4 mt-4">
                            <div className="relative">
                              <input
                                type="file"
                                ref={avatarInputRef}
                                onChange={handleAvatarUpload}
                                className="absolute inset-0 opacity-0 cursor-pointer"
                                accept="image/*"
                                disabled={uploadingAvatar}
                              />
                              <Button variant="outline" className="flex items-center gap-2" disabled={uploadingAvatar}>
                                {uploadingAvatar ? (
                                  <>
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                    Uploading...
                                  </>
                                ) : (
                                  <>
                                    <Upload className="h-4 w-4" />
                                    Upload Avatar
                                  </>
                                )}
                              </Button>
                            </div>

                            {avatar && (
                              <Button
                                variant="outline"
                                className="flex items-center gap-2 text-red-500 hover:text-red-700 hover:bg-red-50 border-red-200"
                                onClick={handleAvatarDelete}
                                disabled={uploadingAvatar}
                              >
                                <Trash2 className="h-4 w-4" />
                                Remove Avatar
                              </Button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="conversations">
                    <div className="space-y-6">
                      <h3 className="text-lg font-medium">Chatbot Conversations</h3>

                      {loadingConversations ? (
                        <div className="flex justify-center items-center h-40">
                          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                        </div>
                      ) : conversations.length === 0 ? (
                        <div className="text-center py-8 border rounded-lg bg-gray-50 dark:bg-gray-900">
                          <MessageSquare className="h-12 w-12 mx-auto text-gray-400" />
                          <p className="mt-2 text-gray-500">No conversations found</p>
                          <p className="text-sm text-gray-400">Your chatbot hasn't had any conversations yet</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 h-[calc(100vh-16rem)]">
                          <div className="lg:h-[calc(100vh-16rem)] overflow-hidden">
                            <Card
                              style={{
                                borderColor: theme.primary_color,
                                borderWidth: "1px",
                                boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
                              }}
                              className="border-b-2"
                            >
                              <CardHeader>
                                <CardTitle>Conversation History</CardTitle>
                              </CardHeader>
                              <CardContent className="flex-grow overflow-hidden">
                                <ScrollArea className="h-[calc(100vh-20rem)] pb-4">
                                  <div className="space-y-2">
                                    {conversations.map((conv) => (
                                      <div
                                        key={conv.date_of_convo}
                                        className="p-3 border rounded-md cursor-pointer hover:bg-gray-50"
                                        onClick={async () => {
                                          await fetchConversationsForDate(conv.date_of_convo)
                                        }}
                                      >
                                        <p className="font-medium">
                                          {new Date(conv.date_of_convo).toLocaleDateString("en-US", {
                                            weekday: "long",
                                            year: "numeric",
                                            month: "long",
                                            day: "numeric",
                                          })}
                                        </p>
                                        <p className="text-sm text-gray-500">
                                          {conv.count} conversation{conv.count !== 1 ? "s" : ""}
                                        </p>
                                      </div>
                                    ))}
                                  </div>
                                </ScrollArea>
                              </CardContent>
                            </Card>
                          </div>

                          <div className="lg:h-[calc(100vh-16rem)] overflow-hidden">
                            <Card
                              className="h-full flex flex-col"
                              style={{ borderColor: theme.secondary_color, borderWidth: "1px" }}
                            >
                              <CardHeader>
                                <CardTitle>{conversationsForDate ? "Conversation Preview" : "Chat Preview"}</CardTitle>
                              </CardHeader>
                              <CardContent className="flex-grow overflow-auto">
                                <ScrollArea className="h-full">
                                  {conversationsForDate ? (
                                    <>
                                      <div className="mb-4">
                                        <label
                                          htmlFor="conversation-select"
                                          className="block text-sm font-medium text-gray-700 mb-1"
                                        >
                                          Select Conversation ({conversationsForDate.conversations.length} total):
                                        </label>
                                        <select
                                          id="conversation-select"
                                          className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-opacity-50 transition-colors"
                                          style={{
                                            borderColor: theme.primary_color,
                                            backgroundColor: "white",
                                            color: "black",
                                            borderRadius: `${theme.border_radius}px`,
                                            boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)",
                                          }}
                                          value={selectedConversationId || ""}
                                          onChange={(e) => {
                                            const newId = e.target.value
                                            handleConversationSelect(newId)
                                          }}
                                        >
                                          {conversationsForDate.conversations.map((conv, index) => (
                                            <option key={conv.id} value={conv.id}>
                                              Conversation {index + 1} -{" "}
                                              {new Date(conv.created_at).toLocaleTimeString()}
                                            </option>
                                          ))}
                                        </select>
                                      </div>

                                      <div className="space-y-4">
                                        {selectedMessages.length > 0 ? (
                                          selectedMessages.map((message, index) => (
                                            <div
                                              key={index}
                                              className={`flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`}
                                            >
                                              <div
                                                className={`max-w-[95%] rounded-lg p-3 break-words`}
                                                style={
                                                  message.role === "assistant"
                                                    ? {
                                                        backgroundColor: "#f3f4f6",
                                                        color: "black",
                                                        borderRadius: `${theme.border_radius}px`,
                                                      }
                                                    : {
                                                        backgroundColor: theme.primary_color,
                                                        color: "white",
                                                        borderRadius: `${theme.border_radius}px`,
                                                      }
                                                }
                                              >
                                                <p className="whitespace-pre-wrap">
                                                  {message.content.replace(/[*#]/g, "")}
                                                </p>
                                              </div>
                                            </div>
                                          ))
                                        ) : (
                                          <div className="text-center py-4">
                                            <p className="text-gray-500">No messages in this conversation</p>
                                          </div>
                                        )}
                                      </div>
                                    </>
                                  ) : (
                                    <div className="flex items-center justify-center h-full">
                                      <p className="text-gray-500">Select a conversation to view details</p>
                                    </div>
                                  )}
                                </ScrollArea>
                              </CardContent>
                            </Card>
                          </div>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Chat Interface - Always visible */}
        <div className="md:col-span-2 relative">
          <div className="sticky top-24">
            <ChatInterface
              chatbotId={params.chatbotId}
              chatbotName={theme.chatbot_name}
              greeting={theme.greeting}
              instruction={theme.instruction}
              avatarUrl={avatar} // Add this line to pass the avatar URL
              themeValues={{
                primaryColor: theme.primary_color,
                secondaryColor: theme.secondary_color,
                borderRadius: theme.border_radius,
                darkMode: theme.dark_mode,
                avatarUrl: avatar, // Add this line to include avatarUrl in themeValues
              }}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
