interface Window {
  isProcessingThemeUpdate?: boolean
  themeAlreadyFetched?: Record<string, boolean>
  themeFetchInProgress?: Record<string, boolean>
  chatbotDataCache?: Record<string, any>
  chatbotDataFetchInProgress?: Record<string, boolean>
}
