import { InternalHero } from "@/app/components/internal-hero"
import { Footer } from "@/app/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function ContactPage() {
  return (
    <>
      <InternalHero title="Contact Us" />
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <p className="text-lg mb-6">
              Have questions or want to learn more about Bot247.live? We're here to help. Fill out the form below, and
              we'll get back to you as soon as possible.
            </p>
            <div className="space-y-4">
              <div>
                <h2 className="text-xl font-semibold mb-2">Email</h2>
                <p>support@bot247.live</p>
              </div>
              <div>
                <h2 className="text-xl font-semibold mb-2">Phone</h2>
                <p>+1 (555) 123-4567</p>
              </div>
              <div>
                <h2 className="text-xl font-semibold mb-2">Address</h2>
                <p>123 AI Street, Tech City, TC 12345, United States</p>
              </div>
            </div>
          </div>
          <form className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Name
              </label>
              <Input type="text" id="name" name="name" required />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Email
              </label>
              <Input type="email" id="email" name="email" required />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Message
              </label>
              <Textarea id="message" name="message" rows={4} required />
            </div>
            <Button type="submit">Send Message</Button>
          </form>
        </div>
      </div>
      <Footer />
    </>
  )
}
