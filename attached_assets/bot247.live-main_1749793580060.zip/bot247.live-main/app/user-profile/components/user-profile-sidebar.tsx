"use client"

import { useRouter } from "next/navigation"
import Link from "next/link"
import { cn } from "@/app/lib/utils"
import { User, CreditCard, LayoutDashboard, Bot } from "lucide-react"

interface UserProfileSidebarProps {
  activePage: string
  chatbotId: string
}

export default function UserProfileSidebar({ activePage, chatbotId }: UserProfileSidebarProps) {
  const router = useRouter()

  const menuItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: LayoutDashboard,
      href: `/dashboard`,
    },
    {
      id: "profile",
      label: "My profile",
      icon: User,
      href: `/user-profile`,
    },
    {
      id: "chatbot",
      label: "Chatbot",
      icon: Bot,
      href: `/create-chatbot/chatbot-interface`,
    },
    {
      id: "billing",
      label: "Billing and usage",
      icon: CreditCard,
      href: `/user-profile/billing`,
    },
  ]

  return (
    <div className="md:col-span-1">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 space-y-4">
        {menuItems.map((item) => (
          <Link
            key={item.id}
            href={item.href}
            className={cn(
              "p-3 rounded-md flex items-center gap-3 cursor-pointer",
              activePage === item.id
                ? "bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400"
                : "hover:bg-gray-100 dark:hover:bg-gray-700",
            )}
          >
            <item.icon className="h-5 w-5" />
            <span className="font-medium">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
