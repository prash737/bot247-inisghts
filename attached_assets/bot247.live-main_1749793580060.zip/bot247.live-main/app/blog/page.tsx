import { InternalHero } from "@/app/components/internal-hero"
import { Footer } from "@/app/components/footer"

const blogPosts = [
  {
    title: "The Future of AI in Education",
    excerpt:
      "Explore how artificial intelligence is transforming the educational landscape, from personalized learning to automated administrative tasks.",
    date: "2023-05-15",
    author: "Dr. Jane Smith",
  },
  {
    title: "Streamlining the Admission Process: A Case Study",
    excerpt:
      "Learn how a leading university improved its admission efficiency by 40% using Bot247.live's AI-powered system.",
    date: "2023-06-02",
    author: "Mark Johnson",
  },
  {
    title: "The Importance of Multilingual Support in Global Education",
    excerpt:
      "Discover why offering support in multiple languages is crucial for institutions aiming to attract international students.",
    date: "2023-06-20",
    author: "Maria Rodriguez",
  },
]

export default function BlogPage() {
  return (
    <>
      <InternalHero title="Bot247.live Blog" />
      <div className="container mx-auto px-4 py-16">
        <div className="space-y-12">
          {blogPosts.map((post, index) => (
            <article key={index} className="border-b border-gray-200 dark:border-gray-700 pb-8">
              <h2 className="text-2xl font-semibold mb-2">{post.title}</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-4">{post.excerpt}</p>
              <div className="text-sm text-gray-500 dark:text-gray-400">
                <span>{post.date}</span> • <span>{post.author}</span>
              </div>
            </article>
          ))}
        </div>
      </div>
      <Footer />
    </>
  )
}
