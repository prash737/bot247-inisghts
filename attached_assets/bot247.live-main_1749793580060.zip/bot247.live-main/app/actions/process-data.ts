"use server"

export async function processJsonPostRequest(url: string, headers: Record<string, string> = {}, jsonBody: object) {
  console.log(`[API Call] POST ${url}`)
  console.log("[API Call] Headers:", headers)
  console.log("[API Call] Body:", jsonBody)

  try {
    // Prepare request options
    const options: RequestInit = {
      method: "POST",
      headers: {
        // Ensure Content-Type is set for JSON
        "Content-Type": "application/json",
        ...headers,
      },
      // Stringify the JSON body
      body: JSON.stringify(jsonBody),
    }

    // Make the request
    const response = await fetch(url, options)
    console.log(`[API Call] Response status: ${response.status} ${response.statusText}`)

    // Get response headers
    const responseHeaders = Object.fromEntries(response.headers.entries())

    // Try to parse response as JSON
    try {
      const data = await response.json()
      return {
        status: response.status,
        statusText: response.statusText,
        headers: responseHeaders,
        data,
      }
    } catch (jsonError) {
      // If not JSON, return as text
      const text = await response.clone().text()
      return {
        status: response.status,
        statusText: response.statusText,
        headers: responseHeaders,
        data: text,
      }
    }
  } catch (error) {
    console.error("[API Call] Error:", error)
    throw new Error(error instanceof Error ? error.message : "Failed to call API")
  }
}

export async function processUserMessage(message: string, chatbotId: string, sessionId?: string) {
  // Use the actual API endpoint instead of the local proxy
  const url = "https://ragbackend-evonix.replit.app/process-data/"

  // Validate chatbotId to ensure it's not default or empty
  if (!chatbotId || chatbotId === "default_chatbot_id") {
    console.warn("Warning: Using default chatbot ID. This may not be intended in production.")

    // Try to get chatbot ID from localStorage as a fallback
    if (typeof window !== "undefined") {
      const userDataStr = localStorage.getItem("userData")
      if (userDataStr) {
        try {
          const userData = JSON.parse(userDataStr)
          if (userData.chatbotId && userData.chatbotId !== "default_chatbot_id") {
            chatbotId = userData.chatbotId
            console.log("Retrieved chatbot ID from localStorage:", chatbotId)
          }
        } catch (error) {
          console.error("Error parsing userData from localStorage:", error)
        }
      }
    }
  }

  // Trim the chatbotId to remove any whitespace or newline characters
  const trimmedChatbotId = chatbotId.trim()
  console.log("Using chatbot ID in processUserMessage:", trimmedChatbotId)

  // Generate dynamic user_id and session_id based on chatbot_id
  const dynamicUserId = trimmedChatbotId // Use chatbot_id as user_id

  // Generate session_id as chatbot_id + today's date (YYYY-MM-DD format)
  const today = new Date()
  const todayString = today.toISOString().split("T")[0] // Gets YYYY-MM-DD format
  const dynamicSessionId = `${trimmedChatbotId}_${todayString}`

  // Log the dynamic IDs being used
  console.log("Using dynamic user ID in processUserMessage:", dynamicUserId)
  console.log("Using dynamic session ID in processUserMessage:", dynamicSessionId)

  // Create request body with dynamic values
  const requestBody = {
    content: message,
    user_id: dynamicUserId, // Using chatbot_id as user_id
    session_id: dynamicSessionId, // Using chatbot_id + today's date as session_id
    chatbot_id: trimmedChatbotId, // Using the trimmed chatbot ID
    metadata: {
      type: "query",
      timestamp: new Date().toISOString(),
      source: "bot247_live",
    },
  }

  return processJsonPostRequest(url, {}, requestBody)
}
