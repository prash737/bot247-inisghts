"use client"
import { Hero } from "@/app/components/hero"
import { Features } from "@/app/components/features"
import { Stats } from "@/app/components/stats"
import { Implementation } from "@/app/components/implementation"
import { Benefits } from "@/app/components/benefits"
import { OurClients } from "@/app/components/our-clients"
import { Pricing } from "@/app/components/pricing"
import { FAQ } from "@/app/components/faq"
import { CTA } from "@/app/components/cta"
import { Footer } from "@/app/components/footer"
import { useScrollToHash } from "./hooks/useScrollToHash"

export default function Home() {
  useScrollToHash()

  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-grow">
        <Hero />
        <Features />
        <Stats />
        <Benefits />
        <OurClients />
        <Implementation />
        <Pricing />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  )
}
