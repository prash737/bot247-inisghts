import KnowledgePageClient from "./KnowledgePageClient"

export default function KnowledgePage() {
  return <KnowledgePageClient />
}
