"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Info, MessageSquare, Plus, X, Paperclip, Trash2, AlertCircle, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/app/lib/utils"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { toast } from "@/components/ui/use-toast"
import { useChatbotTheme } from "@/app/contexts/chatbot-theme-context"
import SharedChatInterface from "@/app/components/shared-chat-interface"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import ChatbotSidebar from "@/app/components/chatbot-sidebar"
import ChatbotHeader from "@/app/components/chatbot-header"
import { logAuditEvent } from "@/app/utils/audit-logger"

// Initialize Supabase client
const supabase = createClient(
  "https://zsivtypgrrcttzhtfjsf.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpzaXZ0eXBncnJjdHR6aHRmanNmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzgzMzU5NTUsImV4cCI6MjA1MzkxMTk1NX0.3cAMZ4LPTqgIc8z6D8LRkbZvEhP_ffI3Wka0-QDSIys",
)

export default function KnowledgePageClient() {
  const router = useRouter()
  const { darkMode, setDarkMode } = useChatbotTheme()

  // State management
  const [activeSection, setActiveSection] = useState("knowledge")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [chatbotName, setChatbotName] = useState("AI Assistant")

  // File upload states
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [fileUploadErrors, setFileUploadErrors] = useState<string[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)

  // URL states
  const [urls, setUrls] = useState<string[]>([""])
  const [urlErrors, setUrlErrors] = useState<string[]>([])
  const [isUploadingUrls, setIsUploadingUrls] = useState(false)
  const [urlUploadSuccess, setUrlUploadSuccess] = useState(false)

  // Add these new state variables after the existing state declarations
  const [existingUrls, setExistingUrls] = useState<string[]>([])
  const [existingDocuments, setExistingDocuments] = useState<string[]>([])
  const [totalKnowledgeSources, setTotalKnowledgeSources] = useState<number>(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [itemToDelete, setItemToDelete] = useState<{ type: "url" | "document" | "domain"; value: string } | null>(null)

  // Domain states - updated to match URL handling
  const [domains, setDomains] = useState<string[]>([""])
  const [domainErrors, setDomainErrors] = useState<string[]>([])
  const [isUploadingDomains, setIsUploadingDomains] = useState(false)
  const [domainUploadSuccess, setDomainUploadSuccess] = useState(false)
  const [existingDomains, setExistingDomains] = useState<string[]>([])
  const [isLoadingDomains, setIsLoadingDomains] = useState(false)
  const [isDeletingDomain, setIsDeletingDomain] = useState(false)
  const [chatbotId, setChatbotId] = useState<string>("")

  // Refresh dialog state
  const [refreshConfirmOpen, setRefreshConfirmOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Effects
  useEffect(() => {
    // Apply theme
    const root = document.documentElement
    if (darkMode) {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }
  }, [darkMode])

  // Load chatbot ID, name and greeting from localStorage on component mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedName = localStorage.getItem("chatbotName")
      if (savedName) {
        setChatbotName(savedName)
      }

      // Get the chatbot ID from userData in localStorage
      const userDataStr = localStorage.getItem("userData")
      if (userDataStr) {
        try {
          const userData = JSON.parse(userDataStr)
          if (userData.chatbotId) {
            setChatbotId(userData.chatbotId)
          }
        } catch (error) {
          console.error("Error parsing userData from localStorage:", error)
        }
      }
    }
  }, [])

  // Fetch theme data from Supabase when component mounts
  useEffect(() => {
    const fetchThemeData = async () => {
      try {
        // Get the chatbot ID from userData in localStorage
        let chatbotId = null

        if (typeof window !== "undefined") {
          const userDataStr = localStorage.getItem("userData")
          if (userDataStr) {
            const userData = JSON.parse(userDataStr)
            if (userData.chatbotId) {
              chatbotId = userData.chatbotId
            }
          }
        }

        if (!chatbotId) return

        // Fetch the theme data from the chatbot_themes table
        const { data, error } = await supabase.from("chatbot_themes").select("*").eq("chatbot_id", chatbotId).single()

        if (error) {
          console.error("Error fetching theme data:", error)
          return
        }

        if (data) {
          console.log("Theme data loaded for knowledge page:", data)

          if (data.chatbot_name !== null) {
            setChatbotName(data.chatbot_name)
            localStorage.setItem("chatbotName", data.chatbot_name)
          }
        }
      } catch (error) {
        console.error("Error in fetchThemeData:", error)
      }
    }

    fetchThemeData()
  }, [])

  // Add this new useEffect to fetch existing URLs and documents
  useEffect(() => {
    const fetchExistingData = async () => {
      if (!chatbotId) return

      try {
        // Fetch existing URLs
        const { data: urlData, error: urlError } = await supabase
          .from("urls_uploaded")
          .select("url_links")
          .eq("chatbot_id", chatbotId)
          .single()

        if (urlError && urlError.code !== "PGRST116") {
          console.error("Error fetching URLs:", urlError)
        }

        if (urlData && urlData.url_links && urlData.url_links.links) {
          setExistingUrls(urlData.url_links.links)
        }

        // Fetch existing documents
        const { data: documentsData, error: documentsError } = await supabase.storage
          .from("documentuploaded")
          .list(`${chatbotId}/`)

        if (documentsError) {
          console.error("Error fetching documents:", documentsError)
        }

        if (documentsData) {
          // Filter out the .keep file and any other system files
          const documentFiles = documentsData
            .filter((file) => file.name !== ".keep" && !file.name.startsWith("."))
            .map((file) => file.name)
          setExistingDocuments(documentFiles)
        }

        // Calculate total knowledge sources
        const urlCount = urlData?.url_links?.links?.length || 0
        const documentCount =
          documentsData?.filter((file) => file.name !== ".keep" && !file.name.startsWith(".")).length || 0
        setTotalKnowledgeSources(urlCount + documentCount)
      } catch (error) {
        console.error("Error fetching existing data:", error)
      }
    }

    fetchExistingData()
  }, [chatbotId])

  // Add this new useEffect to fetch existing embed domains after the other useEffects
  useEffect(() => {
    const fetchEmbedDomains = async () => {
      if (!chatbotId) return

      setIsLoadingDomains(true)
      try {
        // Fetch existing embed domains
        const { data, error } = await supabase
          .from("embed_domains")
          .select("domains")
          .eq("chatbot_id", chatbotId)
          .single()

        if (error && error.code !== "PGRST116") {
          console.error("Error fetching embed domains:", error)
        }

        if (data && data.domains && data.domains.links) {
          setExistingDomains(data.domains.links)
        } else {
          setExistingDomains([])
        }
      } catch (error) {
        console.error("Error in fetchEmbedDomains:", error)
      } finally {
        setIsLoadingDomains(false)
      }
    }

    fetchEmbedDomains()
  }, [chatbotId])

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    const validFiles: File[] = []
    const errors: string[] = []

    files.forEach((file) => {
      const fileExtension = file.name.split(".").pop()?.toLowerCase()

      if (fileExtension === "pdf" || fileExtension === "docx") {
        validFiles.push(file)
      } else {
        errors.push(`${file.name}: Only PDF and DOCX files are allowed`)
      }
    })

    setSelectedFiles((prev) => [...prev, ...validFiles])

    if (errors.length > 0) {
      setFileUploadErrors(errors)
      toast({
        title: "Invalid file type",
        description: "Only PDF and DOCX files are allowed",
        variant: "destructive",
      })
    }
  }

  // Handle file removal
  const handleRemoveFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  // Upload all files to Supabase
  const uploadAllFiles = async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select files to upload",
        variant: "destructive",
      })
      return
    }

    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to upload files for.",
        variant: "destructive",
      })
      return
    }

    // Check if adding these files would exceed the 20 source limit
    const totalAfterUpload = totalKnowledgeSources + selectedFiles.length
    if (totalAfterUpload > 20) {
      toast({
        title: "Source limit exceeded",
        description: `You can only have 20 knowledge sources in total. You currently have ${totalKnowledgeSources} sources and are trying to add ${selectedFiles.length} more.`,
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    setUploadSuccess(false)

    try {
      // Rest of the function remains the same...
      // Check if the folder exists
      const folderPath = `${chatbotId}/`
      const { data: folderData, error: folderError } = await supabase.storage.from("documentuploaded").list(folderPath)

      // If there's an error and it's not "not found", throw it
      if (folderError && folderError.message !== "The resource was not found") {
        throw folderError
      }

      // If folder doesn't exist (empty array or error), create it by uploading an empty file
      if (!folderData || folderData.length === 0) {
        const { error: createFolderError } = await supabase.storage
          .from("documentuploaded")
          .upload(`${folderPath}.keep`, new Blob([]), { upsert: true })

        if (createFolderError) {
          throw createFolderError
        }
      }

      // Upload all files
      const uploadPromises = selectedFiles.map((file) => {
        return supabase.storage.from("documentuploaded").upload(`${folderPath}${file.name}`, file, { upsert: true })
      })

      const results = await Promise.all(uploadPromises)

      // Check for errors
      const uploadErrors = results.filter((result) => result.error)

      if (uploadErrors.length > 0) {
        throw new Error(`Failed to upload ${uploadErrors.length} files`)
      }

      // Log to audit_logs
      const fileNames = selectedFiles.map((file) => file.name)
      await logAuditEvent(chatbotId, {
        documents_added: {
          previous: null,
          current: fileNames,
        },
      })

      // Success
      setSelectedFiles([])
      setUploadSuccess(true)
      toast({
        title: "Upload successful",
        description: `Successfully uploaded ${selectedFiles.length} files`,
      })

      // Refresh the list of documents immediately
      const { data: updatedDocumentsData, error: refreshError } = await supabase.storage
        .from("documentuploaded")
        .list(folderPath)

      if (refreshError) {
        console.error("Error refreshing document list:", refreshError)
      } else if (updatedDocumentsData) {
        const documentFiles = updatedDocumentsData
          .filter((file) => file.name !== ".keep" && !file.name.startsWith("."))
          .map((file) => file.name)
        setExistingDocuments(documentFiles)

        // Update total count
        setTotalKnowledgeSources(existingUrls.length + documentFiles.length)
      }
    } catch (error) {
      console.error("Error uploading files:", error)
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  // Validate URL
  const validateUrl = (url: string): boolean => {
    try {
      new URL(url)
      return true
    } catch (e) {
      return false
    }
  }

  // Handle URL input change
  const handleUrlChange = (index: number, value: string) => {
    const newUrls = [...urls]
    newUrls[index] = value
    setUrls(newUrls)

    const newErrors = [...urlErrors]
    if (value && !validateUrl(value)) {
      newErrors[index] = "Please enter a valid URL"
    } else {
      newErrors[index] = ""
    }
    setUrlErrors(newErrors)
  }

  // Add URL input field
  const handleAddUrl = () => {
    setUrls([...urls, ""])
    setUrlErrors([...urlErrors, ""])
  }

  // Remove URL input field
  const handleRemoveUrl = (index: number) => {
    const newUrls = [...urls]
    newUrls.splice(index, 1)
    setUrls(newUrls)

    const newErrors = [...urlErrors]
    newErrors.splice(index, 1)
    setUrlErrors(newErrors)
  }

  // Upload URLs to Supabase
  const uploadUrls = async () => {
    // Filter out empty URLs
    const validUrls = urls.filter((url) => url.trim() !== "")

    if (validUrls.length === 0) {
      toast({
        title: "No URLs entered",
        description: "Please enter at least one valid URL",
        variant: "destructive",
      })
      return
    }

    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to upload URLs for.",
        variant: "destructive",
      })
      return
    }

    // Check if all URLs are valid
    const hasErrors = urlErrors.some((error) => error !== "")
    if (hasErrors) {
      toast({
        title: "Invalid URLs",
        description: "Please correct the errors before uploading",
        variant: "destructive",
      })
      return
    }

    // Check if adding these URLs would exceed the 20 source limit
    const totalAfterUpload = totalKnowledgeSources + validUrls.length
    if (totalAfterUpload > 20) {
      toast({
        title: "Source limit exceeded",
        description: `You can only have 20 knowledge sources in total. You currently have ${totalKnowledgeSources} sources and are trying to add ${validUrls.length} more.`,
        variant: "destructive",
      })
      return
    }

    setIsUploadingUrls(true)
    setUrlUploadSuccess(false)

    try {
      // Check if there are existing URLs
      const { data: existingUrlData, error: existingUrlError } = await supabase
        .from("urls_uploaded")
        .select("url_links")
        .eq("chatbot_id", chatbotId)
        .single()

      let combinedUrls: string[] = []

      if (existingUrlData && existingUrlData.url_links && existingUrlData.url_links.links) {
        // Combine existing URLs with new ones
        combinedUrls = [...existingUrlData.url_links.links, ...validUrls]
      } else {
        combinedUrls = validUrls
      }

      // Format URLs as required JSON
      const urlData = {
        links: combinedUrls,
      }

      if (existingUrlData) {
        // Update existing record
        const { error } = await supabase
          .from("urls_uploaded")
          .update({ url_links: urlData })
          .eq("chatbot_id", chatbotId)

        if (error) throw error
      } else {
        // Insert new record
        const { error } = await supabase.from("urls_uploaded").insert([
          {
            chatbot_id: chatbotId,
            url_links: urlData,
          },
        ])

        if (error) throw error
      }

      // Log to audit_logs
      await logAuditEvent(chatbotId, {
        urls_added: {
          previous: existingUrlData?.url_links?.links || null,
          current: validUrls,
        },
      })

      // Success
      setUrls([""])
      setUrlErrors([""])
      setUrlUploadSuccess(true)
      setExistingUrls(combinedUrls)
      setTotalKnowledgeSources(combinedUrls.length + existingDocuments.length)

      toast({
        title: "URLs uploaded successfully",
        description: `Successfully added ${validUrls.length} URLs as knowledge sources`,
      })
    } catch (error) {
      console.error("Error uploading URLs:", error)
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setIsUploadingUrls(false)
    }
  }

  // Handle domain input change - similar to URL handling
  const handleDomainChange = (index: number, value: string) => {
    const newDomains = [...domains]
    newDomains[index] = value
    setDomains(newDomains)

    const newErrors = [...domainErrors]
    if (value && !validateUrl(value)) {
      newErrors[index] = "Please enter a valid URL"
    } else {
      newErrors[index] = ""
    }
    setDomainErrors(newErrors)
  }

  // Add domain input field - similar to URL handling
  const handleAddDomain = () => {
    setDomains([...domains, ""])
    setDomainErrors([...domainErrors, ""])
  }

  // Remove domain input field - similar to URL handling
  const handleRemoveDomain = (index: number) => {
    const newDomains = [...domains]
    newDomains.splice(index, 1)
    setDomains(newDomains)

    const newErrors = [...domainErrors]
    newErrors.splice(index, 1)
    setDomainErrors(newErrors)
  }

  // Upload domains to Supabase - similar to URL handling
  const uploadDomains = async () => {
    // Filter out empty domains
    const validDomains = domains.filter((domain) => domain.trim() !== "")

    if (validDomains.length === 0) {
      toast({
        title: "No domains entered",
        description: "Please enter at least one valid domain",
        variant: "destructive",
      })
      return
    }

    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to upload domains for.",
        variant: "destructive",
      })
      return
    }

    // Check if all domains are valid
    const hasErrors = domainErrors.some((error) => error !== "")
    if (hasErrors) {
      toast({
        title: "Invalid domains",
        description: "Please correct the errors before uploading",
        variant: "destructive",
      })
      return
    }

    setIsUploadingDomains(true)
    setDomainUploadSuccess(false)

    try {
      // Check if there are existing domains
      const { data: existingData, error: existingError } = await supabase
        .from("embed_domains")
        .select("domains")
        .eq("chatbot_id", chatbotId)
        .single()

      let combinedDomains: string[] = []

      if (existingData && existingData.domains && existingData.domains.links) {
        // Combine existing domains with new ones
        combinedDomains = [...existingData.domains.links, ...validDomains]
      } else {
        combinedDomains = validDomains
      }

      // Format domains as required JSON
      const domainData = {
        links: combinedDomains,
      }

      if (existingData) {
        // Update existing record
        const { error } = await supabase
          .from("embed_domains")
          .update({ domains: domainData })
          .eq("chatbot_id", chatbotId)

        if (error) throw error
      } else {
        // Insert new record
        const { error } = await supabase.from("embed_domains").insert([
          {
            chatbot_id: chatbotId,
            domains: domainData,
          },
        ])

        if (error) throw error
      }

      // Log to audit_logs
      await logAuditEvent(chatbotId, {
        domains_added: {
          previous: existingData?.domains?.links || null,
          current: validDomains,
        },
      })

      // Success
      setDomains([""])
      setDomainErrors([""])
      setDomainUploadSuccess(true)
      setExistingDomains(combinedDomains)

      toast({
        title: "Domains uploaded successfully",
        description: `Successfully added ${validDomains.length} domains to your embed list`,
      })
    } catch (error) {
      console.error("Error uploading domains:", error)
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setIsUploadingDomains(false)
    }
  }

  const deleteEmbedDomain = async (domain: string) => {
    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to delete domain from.",
        variant: "destructive",
      })
      return
    }

    setIsDeletingDomain(true)

    try {
      // Get current domains
      const { data, error } = await supabase
        .from("embed_domains")
        .select("domains")
        .eq("chatbot_id", chatbotId)
        .single()

      if (error) throw error

      if (!data || !data.domains || !data.domains.links) {
        throw new Error("No domains found")
      }

      // Filter out the domain to delete
      const updatedDomains = data.domains.links.filter((existingDomain: string) => existingDomain !== domain)

      // Update the record
      const { error: updateError } = await supabase
        .from("embed_domains")
        .update({ domains: { links: updatedDomains } })
        .eq("chatbot_id", chatbotId)

      if (updateError) throw updateError

      // Log to audit_logs
      await logAuditEvent(chatbotId, {
        domain_deleted: {
          previous: domain,
          current: null,
        },
      })

      // Update state
      setExistingDomains(updatedDomains)

      toast({
        title: "Domain deleted",
        description: "The domain has been removed from your embed list",
      })
    } catch (error) {
      console.error("Error deleting domain:", error)
      toast({
        title: "Delete failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setIsDeletingDomain(false)
    }
  }

  // Handle delete confirmation
  const handleDeleteConfirm = (type: "url" | "document" | "domain", value: string) => {
    setItemToDelete({ type: type as any, value })
    setDeleteConfirmOpen(true)
  }

  // Delete URL from Supabase
  const deleteUrl = async (url: string) => {
    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to delete URL from.",
        variant: "destructive",
      })
      return
    }

    setIsDeleting(true)

    try {
      // Get current URLs
      const { data, error } = await supabase
        .from("urls_uploaded")
        .select("url_links")
        .eq("chatbot_id", chatbotId)
        .single()

      if (error) throw error

      if (!data || !data.url_links || !data.url_links.links) {
        throw new Error("No URLs found")
      }

      // Filter out the URL to delete
      const updatedUrls = data.url_links.links.filter((existingUrl: string) => existingUrl !== url)

      // Update the record
      const { error: updateError } = await supabase
        .from("urls_uploaded")
        .update({ url_links: { links: updatedUrls } })
        .eq("chatbot_id", chatbotId)

      if (updateError) throw updateError

      // Log to audit_logs
      await logAuditEvent(chatbotId, {
        url_deleted: {
          previous: url,
          current: null,
        },
      })

      // Update state
      setExistingUrls(updatedUrls)
      setTotalKnowledgeSources(updatedUrls.length + existingDocuments.length)

      toast({
        title: "URL deleted",
        description: "The URL has been removed from your knowledge sources",
      })
    } catch (error) {
      console.error("Error deleting URL:", error)
      toast({
        title: "Delete failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      // Refresh knowledge sources to ensure UI is up-to-date
      await refreshKnowledgeSources()
      setIsDeleting(false)
    }
  }

  // Delete document from Supabase storage
  const deleteDocument = async (fileName: string) => {
    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to delete document from.",
        variant: "destructive",
      })
      return
    }

    setIsDeleting(true)

    try {
      // Delete the file
      const { error } = await supabase.storage.from("documentuploaded").remove([`${chatbotId}/${fileName}`])

      if (error) throw error

      // Log to audit_logs
      await logAuditEvent(chatbotId, {
        document_deleted: {
          previous: fileName,
          current: null,
        },
      })

      // Update state
      const updatedDocuments = existingDocuments.filter((doc) => doc !== fileName)
      setExistingDocuments(updatedDocuments)
      setTotalKnowledgeSources(existingUrls.length + updatedDocuments.length)

      toast({
        title: "Document deleted",
        description: "The document has been removed from your knowledge sources",
      })
    } catch (error) {
      console.error("Error deleting document:", error)
      toast({
        title: "Delete failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      // Refresh knowledge sources to ensure UI is up-to-date
      await refreshKnowledgeSources()
      setIsDeleting(false)
    }
  }

  // Add this function after the existing functions
  const refreshKnowledgeSources = async () => {
    if (!chatbotId) return

    try {
      // Refresh URLs
      const { data: urlData, error: urlError } = await supabase
        .from("urls_uploaded")
        .select("url_links")
        .eq("chatbot_id", chatbotId)
        .single()

      if (urlError && urlError.code !== "PGRST116") {
        console.error("Error refreshing URLs:", urlError)
      }

      if (urlData && urlData.url_links && urlData.url_links.links) {
        setExistingUrls(urlData.url_links.links)
      } else {
        setExistingUrls([])
      }

      // Refresh documents
      const { data: documentsData, error: documentsError } = await supabase.storage
        .from("documentuploaded")
        .list(`${chatbotId}/`)

      if (documentsError) {
        console.error("Error refreshing documents:", documentsError)
      }

      if (documentsData) {
        const documentFiles = documentsData
          .filter((file) => file.name !== ".keep" && !file.name.startsWith("."))
          .map((file) => file.name)
        setExistingDocuments(documentFiles)
      } else {
        setExistingDocuments([])
      }

      // Update total count
      const urlCount = urlData?.url_links?.links?.length || 0
      const documentCount =
        documentsData?.filter((file) => file.name !== ".keep" && !file.name.startsWith(".")).length || 0
      setTotalKnowledgeSources(urlCount + documentCount)
    } catch (error) {
      console.error("Error refreshing knowledge sources:", error)
    }
  }

  // Process delete action
  const processDelete = async () => {
    if (!itemToDelete) return

    if (itemToDelete.type === "url") {
      await deleteUrl(itemToDelete.value)
    } else if (itemToDelete.type === "document") {
      await deleteDocument(itemToDelete.value)
    } else if (itemToDelete.type === "domain") {
      await deleteEmbedDomain(itemToDelete.value)
    }

    // Refresh knowledge sources after deletion
    await refreshKnowledgeSources()

    setDeleteConfirmOpen(false)
    setItemToDelete(null)
  }

  // Handle refresh confirmation
  const handleRefreshConfirm = () => {
    setRefreshConfirmOpen(true)
  }

  // Process refresh action
  const processRefresh = async () => {
    if (!chatbotId) {
      toast({
        title: "Missing chatbot ID",
        description: "Could not determine which chatbot to refresh URLs for.",
        variant: "destructive",
      })
      return
    }

    setIsRefreshing(true)

    try {
      // Check if the record exists
      const { data, error } = await supabase.from("urls_uploaded").select("*").eq("chatbot_id", chatbotId).single()

      if (error && error.code !== "PGRST116") {
        throw error
      }

      if (data) {
        // Update existing record
        const { error: updateError } = await supabase
          .from("urls_uploaded")
          .update({ refresh: "Yes" })
          .eq("chatbot_id", chatbotId)

        if (updateError) throw updateError
      } else {
        // If no record exists, create one with the refresh flag
        const { error: insertError } = await supabase.from("urls_uploaded").insert([
          {
            chatbot_id: chatbotId,
            url_links: { links: [] },
            refresh: "Yes",
          },
        ])

        if (insertError) throw insertError
      }

      // Log to audit_logs
      await logAuditEvent(chatbotId, {
        urls_refreshed: {
          previous: null,
          current: "Requested refresh of all URLs",
        },
      })

      toast({
        title: "Refresh requested",
        description: "Your URLs will be refreshed shortly.",
      })
    } catch (error) {
      console.error("Error requesting URL refresh:", error)
      toast({
        title: "Refresh request failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setIsRefreshing(false)
      setRefreshConfirmOpen(false)
    }
  }

  // Navigation
  const handleSectionClick = (section: string) => {
    if (section === "directive" || section === "instructions") {
      // Navigate to the instructions page
      router.push("/create-chatbot/chatbot-interface")
    } else if (section === "knowledge") {
      // Already on the knowledge page
      setActiveSection("knowledge")
    } else if (section === "theme") {
      router.push("/create-chatbot/theme")
    } else if (section === "conversations") {
      router.push("/conversations")
    } else if (section === "settings") {
      router.push("/settings")
    } else if (section === "logic") {
      router.push("/logic")
    } else if (section === "analytics") {
      router.push("/analytics")
    } else if (section === "integrations") {
      router.push("/integrations")
    } else {
      setActiveSection(section)
    }
  }

  return (
    <div
      className={cn(
        "flex flex-col h-screen bg-background transition-all duration-300",
        isFullscreen ? "fixed inset-0 z-50" : "",
      )}
    >
      {/* Top Navigation Bar */}
      <ChatbotHeader chatbotName={chatbotName} isScrolled={isScrolled} />

      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        {!isFullscreen && <ChatbotSidebar activeSection="knowledge" />}
        {/* Main Content */}
        <div className="flex-1 overflow-auto bg-gradient-to-br from-blue-50/30 to-green-50/30 dark:bg-gray-900 dark:text-gray-100 transition-colors duration-300 scrollbar-hide">
          <div className="p-6 max-w-4xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <h1 className="text-xl font-semibold">
                  Knowledge sources ({totalKnowledgeSources}/20)
                  {totalKnowledgeSources >= 20 && (
                    <span className="ml-2 text-sm text-red-500 font-normal">(Limit reached)</span>
                  )}
                </h1>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 ml-2 text-gray-400" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Add and manage knowledge sources for your chatbot</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              {/* Refresh Button - Only show if URLs exist */}
              {existingUrls.length > 0 && (
                <Button
                  onClick={handleRefreshConfirm}
                  variant="outline"
                  className="flex items-center text-blue-600 border-blue-200 hover:bg-blue-50 hover:text-blue-700 dark:text-blue-400 dark:border-blue-800 dark:hover:bg-blue-900/30"
                  disabled={isRefreshing}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  {isRefreshing ? "Refreshing..." : "Refresh URLs"}
                </Button>
              )}
            </div>

            <div className="mb-6">
              <p className="text-gray-600 dark:text-gray-300">
                Your current plan gives you access to a maximum of 20 knowledge sources (URLs and documents combined)
                and weekly/monthly syncing.{" "}
              </p>
            </div>

            <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg flex items-start">
              <div className="mr-3 mt-0.5 bg-blue-100 dark:bg-blue-800 rounded-full p-1.5">
                <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h4 className="font-medium text-blue-700 dark:text-blue-300">Processing Time</h4>
                <p className="text-sm text-blue-600 dark:text-blue-400">
                  Your chatbot will be ready with all your updated documents and URLs within 1800 seconds! Bot247.live
                  is analyzing your information to ensure accurate responses.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Document Upload Section */}
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <h3 className="font-medium mb-4">Upload Documents</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  Upload PDF and DOCX files as knowledge sources for your chatbot. These documents will be processed and
                  used to train your chatbot.
                </p>

                <div className="flex items-center space-x-2 mb-4">
                  <label className="cursor-pointer">
                    <div className="flex items-center space-x-2 px-4 py-2 bg-green-50 dark:bg-green-900/20 hover:bg-green-100 dark:hover:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg transition-colors">
                      <Plus className="h-4 w-4" />
                      <span>{selectedFiles.length === 0 ? "Select Files" : "Add More"}</span>
                    </div>
                    <input type="file" className="hidden" accept=".pdf,.docx" multiple onChange={handleFileSelect} />
                  </label>

                  <Button
                    onClick={uploadAllFiles}
                    disabled={selectedFiles.length === 0 || isUploading || totalKnowledgeSources >= 20}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    {isUploading ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                        Uploading...
                      </>
                    ) : totalKnowledgeSources >= 20 ? (
                      "Limit Reached"
                    ) : (
                      "Upload All Files"
                    )}
                  </Button>
                </div>

                {fileUploadErrors.length > 0 && (
                  <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg">
                    <p className="font-medium">The following errors occurred:</p>
                    <ul className="list-disc list-inside text-sm">
                      {fileUploadErrors.map((error, index) => (
                        <li key={index}>{error}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {uploadSuccess && (
                  <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-lg">
                    <p>Files uploaded successfully!</p>
                  </div>
                )}

                {selectedFiles.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Selected Files ({selectedFiles.length})</h4>
                    <div className="max-h-60 overflow-y-auto scrollbar-hide space-y-2">
                      {selectedFiles.map((file, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-2 rounded-lg"
                        >
                          <div className="flex items-center">
                            <div className="bg-blue-100 dark:bg-blue-900/50 p-2 rounded-full mr-2">
                              <Paperclip className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div>
                              <p className="text-sm font-medium truncate max-w-xs">{file.name}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">
                                {(file.size / 1024).toFixed(2)} KB • {file.type}
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-red-500"
                            onClick={() => handleRemoveFile(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {existingDocuments.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Existing Documents ({existingDocuments.length})</h4>
                    <div className="max-h-60 overflow-y-auto scrollbar-hide space-y-2 bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                      {existingDocuments.map((fileName, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="bg-blue-100 dark:bg-blue-900/50 p-2 rounded-full mr-2">
                              <Paperclip className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </div>
                            <p className="text-sm truncate max-w-xs">{fileName}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-red-500"
                            onClick={() => handleDeleteConfirm("document", fileName)}
                            disabled={isDeleting}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* URL Upload Section */}
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mt-6">
                <h3 className="font-medium mb-4">Add Website URLs</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  Add website URLs as knowledge sources for your chatbot. These websites will be crawled and their
                  content will be used to train your chatbot.
                </p>

                <div className="space-y-3 mb-4">
                  {urls.map((url, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="flex-grow">
                        <Input
                          type="url"
                          value={url}
                          onChange={(e) => handleUrlChange(index, e.target.value)}
                          placeholder="https://example.com"
                          className={urlErrors[index] ? "border-red-500" : ""}
                          style={{
                            borderRadius: `var(--border-radius)px`,
                            borderColor: `var(--primary-color)50`,
                          }}
                        />
                        {urlErrors[index] && <p className="text-xs text-red-500 mt-1">{urlErrors[index]}</p>}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveUrl(index)}
                        disabled={urls.length === 1}
                        className="h-10 w-10 text-gray-500 hover:text-red-500"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="flex items-center space-x-2">
                  <Button onClick={handleAddUrl} variant="outline" className="flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Another URL
                  </Button>

                  <Button
                    onClick={uploadUrls}
                    disabled={isUploadingUrls || urls.every((url) => !url.trim()) || totalKnowledgeSources >= 20}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    {isUploadingUrls ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                        Uploading...
                      </>
                    ) : totalKnowledgeSources >= 20 ? (
                      "Limit Reached"
                    ) : (
                      "Upload and Confirm URLs"
                    )}
                  </Button>
                </div>

                {urlUploadSuccess && (
                  <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-lg">
                    <p>URLs uploaded successfully!</p>
                  </div>
                )}
                {existingUrls.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Existing URLs ({existingUrls.length})</h4>
                    <div className="max-h-60 overflow-y-auto scrollbar-hide space-y-2 bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                      {existingUrls.map((url, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="bg-indigo-100 dark:bg-indigo-900/50 p-2 rounded-full mr-2">
                              <MessageSquare className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                            </div>
                            <a
                              href={url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm truncate max-w-xs hover:text-indigo-600 dark:hover:text-indigo-400"
                            >
                              {url}
                            </a>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-red-500"
                            onClick={() => handleDeleteConfirm("url", url)}
                            disabled={isDeleting}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Embed Domains Section */}
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 mt-6">
                <h3 className="font-medium mb-4">Allowed Embed Domains</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  Add website domains where your chatbot can be embedded. Only these domains will be allowed to embed
                  your chatbot.
                </p>

                <div className="space-y-3 mb-4">
                  {domains.map((domain, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="flex-grow">
                        <Input
                          type="url"
                          value={domain}
                          onChange={(e) => handleDomainChange(index, e.target.value)}
                          placeholder="https://example.com"
                          className={domainErrors[index] ? "border-red-500" : ""}
                          style={{
                            borderRadius: `var(--border-radius)px`,
                            borderColor: `var(--primary-color)50`,
                          }}
                        />
                        {domainErrors[index] && <p className="text-xs text-red-500 mt-1">{domainErrors[index]}</p>}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveDomain(index)}
                        disabled={domains.length === 1}
                        className="h-10 w-10 text-gray-500 hover:text-red-500"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="flex items-center space-x-2">
                  <Button onClick={handleAddDomain} variant="outline" className="flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Another Domain
                  </Button>

                  <Button
                    onClick={uploadDomains}
                    disabled={isUploadingDomains || domains.every((domain) => !domain.trim())}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white"
                  >
                    {isUploadingDomains ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                        Uploading...
                      </>
                    ) : (
                      "Upload and Confirm Domains"
                    )}
                  </Button>
                </div>

                {domainUploadSuccess && (
                  <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-lg">
                    <p>Domains uploaded successfully!</p>
                  </div>
                )}
                {existingDomains.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Allowed Domains ({existingDomains.length})</h4>
                    <div className="max-h-60 overflow-y-auto scrollbar-hide space-y-2 bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                      {existingDomains.map((domain, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="bg-green-100 dark:bg-green-900/50 p-2 rounded-full mr-2">
                              <MessageSquare className="h-4 w-4 text-green-600 dark:text-green-400" />
                            </div>
                            <a
                              href={domain}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm truncate max-w-xs hover:text-green-600 dark:hover:text-green-400"
                            >
                              {domain}
                            </a>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-red-500"
                            onClick={() => handleDeleteConfirm("domain", domain)}
                            disabled={isDeletingDomain}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Chat Interface */}
        <SharedChatInterface isFullscreen={isFullscreen} />
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
              Confirm Deletion
            </AlertDialogTitle>
            <AlertDialogDescription>
              {itemToDelete?.type === "url"
                ? `Are you sure you want to delete this URL from your knowledge sources? This action cannot be undone.`
                : itemToDelete?.type === "document"
                  ? `Are you sure you want to delete the document "${itemToDelete?.value}" from your knowledge sources? This action cannot be undone.`
                  : `Are you sure you want to delete the domain "${itemToDelete?.value}" from the allowed embed domains? This action cannot be undone.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={processDelete}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-500"
            >
              {isDeleting ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Refresh Confirmation Dialog */}
      <AlertDialog open={refreshConfirmOpen} onOpenChange={setRefreshConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center">
              <RefreshCw className="h-5 w-5 text-blue-500 mr-2" />
              Confirm URL Refresh
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to refresh all your URLs? This will update the content from all your knowledge
              sources. This process may take some time to complete.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isRefreshing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={processRefresh}
              disabled={isRefreshing}
              className="bg-blue-600 hover:bg-blue-700 focus:ring-blue-500"
            >
              {isRefreshing ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                  Refreshing...
                </>
              ) : (
                "Refresh URLs"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
