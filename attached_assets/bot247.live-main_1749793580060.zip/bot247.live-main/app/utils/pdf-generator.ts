import jsPDF from "jspdf"

export async function generateInsightsPDF(
  chatbotName: string,
  insights: any,
  unansweredQueries: { query: string; frequency: number }[],
  totalUnansweredCount: number,
  plots: string[],
) {
  return new Promise<Blob>(async (resolve) => {
    try {
      const pdf = new jsPDF("p", "mm", "a4")
      const pdfWidth = pdf.internal.pageSize.getWidth()
      const pdfHeight = pdf.internal.pageSize.getHeight()
      let currentY = 10 // Starting Y position

      // Add header and title
      pdf.setFontSize(22)
      pdf.setTextColor(79, 70, 229) // Indigo color
      pdf.text("Chatbot Insights Report", pdfWidth / 2, currentY, { align: "center" })

      currentY += 10
      pdf.setFontSize(16)
      pdf.setTextColor(55, 65, 81) // Gray-700
      pdf.text(chatbotName, pdfWidth / 2, currentY, { align: "center" })

      currentY += 8
      pdf.setFontSize(10)
      pdf.setTextColor(107, 114, 128) // Gray-500
      pdf.text(`Generated on: ${new Date().toLocaleString()}`, pdfWidth / 2, currentY, { align: "center" })

      currentY += 8
      pdf.setLineWidth(0.5)
      pdf.setDrawColor(229, 231, 235) // Gray-200
      pdf.line(20, currentY, pdfWidth - 20, currentY)

      currentY += 10

      // Add insights metrics section
      if (insights) {
        pdf.setFontSize(14)
        pdf.setTextColor(55, 65, 81) // Gray-700
        pdf.text("Performance Metrics", 20, currentY)

        currentY += 10

        // Create metrics cards
        const cardWidth = (pdfWidth - 50) / 3
        const cardHeight = 30
        const metrics = [
          {
            title: "Total Conversations",
            value: insights.total_conversations,
            change: insights.conversations_change,
            color: [79, 70, 229], // Indigo/blue
          },
          {
            title: "Total User Queries",
            value: insights.total_user_queries,
            change: insights.user_queries_change,
            color: [16, 185, 129], // Green
          },
          {
            title: "Total Assistant Responses",
            value: insights.total_assistant_responses,
            change: insights.assistant_responses_change,
            color: [245, 158, 11], // Amber/orange
          },
        ]

        // Draw metrics cards
        metrics.forEach((metric, index) => {
          const x = 20 + index * (cardWidth + 5)

          // Card background
          pdf.setFillColor(249, 250, 251) // Gray-50
          pdf.setDrawColor(229, 231, 235) // Gray-200
          pdf.roundedRect(x, currentY, cardWidth, cardHeight, 3, 3, "FD")

          // Card title
          pdf.setFontSize(10)
          pdf.setTextColor(107, 114, 128) // Gray-500
          pdf.text(metric.title, x + 5, currentY + 7)

          // Card value
          pdf.setFontSize(16)
          pdf.setTextColor(metric.color[0], metric.color[1], metric.color[2])
          pdf.text(metric.value.toString(), x + 5, currentY + 18)

          // Change percentage
          if (metric.change !== 0) {
            const changeColor = metric.change > 0 ? [16, 185, 129] : [239, 68, 68] // Green or Red
            const changeSymbol = metric.change > 0 ? "↑" : "↓"
            pdf.setFontSize(9)
            pdf.setTextColor(changeColor[0], changeColor[1], changeColor[2])
            pdf.text(`${changeSymbol} ${Math.abs(metric.change).toFixed(2)}%`, x + 5, currentY + 26)
          }
        })

        currentY += cardHeight + 15
      }

      // Add usage meter if available
      if (insights) {
        pdf.setFontSize(14)
        pdf.setTextColor(55, 65, 81) // Gray-700
        pdf.text("Monthly Conversation Usage", 20, currentY)

        currentY += 10

        // Draw usage card
        pdf.setFillColor(249, 250, 251) // Gray-50
        pdf.setDrawColor(229, 231, 235) // Gray-200
        pdf.roundedRect(20, currentY, pdfWidth - 40, 25, 3, 3, "FD")

        // Add usage info - this is placeholder, you'd need to pass actual usage data
        pdf.setFontSize(10)
        pdf.setTextColor(55, 65, 81) // Gray-700
        pdf.text("Current usage information is available in the dashboard", 25, currentY + 15)

        currentY += 35
      }

      // Add visualizations section if plots exist
      if (plots && plots.length > 0) {
        // Add a new page for visualizations
        pdf.addPage()
        currentY = 10

        pdf.setFontSize(14)
        pdf.setTextColor(55, 65, 81) // Gray-700
        pdf.text("Analytics Visualizations", 20, currentY)

        currentY += 10

        try {
          // Load all images first
          const loadedImages = await Promise.all(
            plots.map((plotUrl) => {
              return new Promise<HTMLImageElement>((resolve, reject) => {
                const img = new Image()
                img.crossOrigin = "anonymous"
                img.onload = () => resolve(img)
                img.onerror = () => reject(new Error(`Failed to load image: ${plotUrl}`))
                img.src = plotUrl
              })
            }),
          )

          // Calculate grid layout for 2x2 grid
          const plotsPerRow = 2
          const plotWidth = (pdfWidth - 40) / plotsPerRow
          const plotHeight = 60 // Adjust as needed
          const plotPadding = 5

          // Add all plots to the PDF in a 2x2 grid
          for (let i = 0; i < loadedImages.length; i++) {
            const row = Math.floor(i / plotsPerRow)
            const col = i % plotsPerRow

            const x = 20 + col * (plotWidth + plotPadding)
            const y = currentY + row * (plotHeight + 20)

            // Create a canvas for the image
            const canvas = document.createElement("canvas")
            canvas.width = loadedImages[i].width
            canvas.height = loadedImages[i].height
            const ctx = canvas.getContext("2d")
            if (ctx) {
              ctx.drawImage(loadedImages[i], 0, 0)
              const imgData = canvas.toDataURL("image/png")

              // Add plot image
              pdf.addImage(imgData, "PNG", x, y, plotWidth, plotHeight)

              // Add plot name
              const plotName = decodeURIComponent(plots[i].split("/").pop()?.split(".")[0] || `Plot ${i + 1}`)
              pdf.setFontSize(8)
              pdf.setTextColor(107, 114, 128) // Gray-500
              pdf.text(plotName, x + plotWidth / 2, y + plotHeight + 5, { align: "center", maxWidth: plotWidth })
            }
          }

          // Update currentY to after the last row of plots
          const totalRows = Math.ceil(loadedImages.length / plotsPerRow)
          currentY += totalRows * (plotHeight + 20) + 10
        } catch (error) {
          console.error("Error adding plots to PDF:", error)
          pdf.setFontSize(10)
          pdf.setTextColor(239, 68, 68) // Red
          pdf.text("Could not include visualizations due to technical limitations.", 20, currentY + 10)
          pdf.text("Please view them in the dashboard.", 20, currentY + 20)
          currentY += 30
        }
      }

      // Add unanswered queries section if they exist
      if (unansweredQueries && unansweredQueries.length > 0) {
        // Start a new page for unanswered queries
        pdf.addPage()
        currentY = 10

        pdf.setFontSize(14)
        pdf.setTextColor(55, 65, 81) // Gray-700
        pdf.text(`Unanswered Queries (${totalUnansweredCount} total)`, 20, currentY)

        currentY += 10

        // Table header
        pdf.setFillColor(243, 244, 246) // Gray-100
        pdf.rect(20, currentY, pdfWidth - 40, 10, "F")

        pdf.setFontSize(10)
        pdf.setTextColor(55, 65, 81) // Gray-700
        pdf.text("Query", 25, currentY + 7)
        pdf.text("Frequency", pdfWidth - 45, currentY + 7)

        currentY += 10

        // Table rows
        const rowHeight = 8
        const maxRowsPerPage = Math.floor((pdfHeight - currentY - 20) / rowHeight)

        for (let i = 0; i < unansweredQueries.length; i++) {
          // Start a new page if needed
          if (i > 0 && i % maxRowsPerPage === 0) {
            pdf.addPage()
            currentY = 10

            pdf.setFontSize(14)
            pdf.setTextColor(55, 65, 81) // Gray-700
            pdf.text(`Unanswered Queries (continued)`, 20, currentY)

            currentY += 10

            // Table header on new page
            pdf.setFillColor(243, 244, 246) // Gray-100
            pdf.rect(20, currentY, pdfWidth - 40, 10, "F")

            pdf.setFontSize(10)
            pdf.setTextColor(55, 65, 81) // Gray-700
            pdf.text("Query", 25, currentY + 7)
            pdf.text("Frequency", pdfWidth - 45, currentY + 7)

            currentY += 10
          }

          // Alternate row background
          if (i % 2 === 0) {
            pdf.setFillColor(249, 250, 251) // Gray-50
            pdf.rect(20, currentY, pdfWidth - 40, rowHeight, "F")
          }

          // Row content
          pdf.setFontSize(9)
          pdf.setTextColor(55, 65, 81) // Gray-700

          // Truncate query if too long
          const query = unansweredQueries[i].query
          const maxQueryLength = 60
          const displayQuery = query.length > maxQueryLength ? query.substring(0, maxQueryLength) + "..." : query

          pdf.text(displayQuery, 25, currentY + 5.5)

          // Frequency with badge-like styling
          const frequency = unansweredQueries[i].frequency
          const frequencyText = `${frequency} ${frequency === 1 ? "time" : "times"}`

          pdf.text(frequencyText, pdfWidth - 45, currentY + 5.5)

          currentY += rowHeight
        }
      }

      // Generate PDF blob
      const pdfBlob = pdf.output("blob")
      resolve(pdfBlob)
    } catch (error) {
      console.error("Error in PDF generation:", error)
      // Return a simple error PDF instead of failing completely
      const errorPdf = new jsPDF()
      errorPdf.setFontSize(16)
      errorPdf.setTextColor(220, 38, 38) // Red color
      errorPdf.text("Error generating report", 20, 20)
      errorPdf.setFontSize(12)
      errorPdf.setTextColor(0, 0, 0)
      errorPdf.text("Please try again later or contact support.", 20, 30)
      resolve(errorPdf.output("blob"))
    }
  })
}
