import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client
const supabase = createClient(
  "https://zsivtypgrrcttzhtfjsf.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpzaXZ0eXBncnJjdHR6aHRmanNmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzgzMzU5NTUsImV4cCI6MjA1MzkxMTk1NX0.3cAMZ4LPTqgIc8z6D8LRkbZvEhP_ffI3Wka0-QDSIys",
)

/**
 * Logs an audit event to the audit_logs table
 *
 * @param chatbotId - The ID of the chatbot
 * @param changeBy - Who made the change ("user" | "admin")
 * @param changes - Object containing the changes made (with previous/current values)
 * @returns Promise that resolves when the log is inserted
 */
export async function logAuditEvent(
  chatbotId: string,
  changesOrChangeBy?: Record<string, { previous: any; current: any }> | "user" | "admin",
  changes?: Record<string, { previous: any; current: any }>,
): Promise<void> {
  try {
    let actualChanges: Record<string, { previous: any; current: any }>
    let changeBy = "user" // Default value

    // Handle different parameter patterns
    if (typeof changesOrChangeBy === "string") {
      // If second parameter is a string (changeBy), use the third parameter as changes
      changeBy = changesOrChangeBy
      actualChanges = changes || {}
    } else {
      // If second parameter is an object (changes), use it directly
      actualChanges = changesOrChangeBy || {}
    }

    // Safety check - if actualChanges is null or undefined, use an empty object
    if (!actualChanges) {
      console.warn("No changes provided to logAuditEvent, using empty object")
      actualChanges = {}
    }

    // Skip logging if there are no actual changes
    if (Object.keys(actualChanges).length === 0) {
      console.log("No changes to log in audit event, skipping")
      return
    }

    // Format changes for better readability
    const formattedChanges: Record<string, string> = {}

    for (const [key, value] of Object.entries(actualChanges)) {
      if (value && typeof value === "object" && "previous" in value && "current" in value) {
        // Skip logging if previous and current values are the same
        if (JSON.stringify(value.previous) === JSON.stringify(value.current)) {
          console.log(`Skipping audit log for ${key} - values are identical`)
          continue
        }

        // Skip logging for default values that haven't actually changed
        if (
          key === "avatar_url" &&
          (value.previous === "/images/default-avatar.png" || value.previous === "/abstract-ai-network.png") &&
          (value.current === "/images/default-avatar.png" || value.current === "/abstract-ai-network.png")
        ) {
          console.log(`Skipping audit log for ${key} - both are default values`)
          continue
        }

        // Skip logging for pulsating_effect if both values represent the same state
        if (
          key === "pulsating_effect" &&
          ((value.previous === "Yes" && value.current === "Yes") || (value.previous === "No" && value.current === "No"))
        ) {
          console.log(`Skipping audit log for ${key} - values represent same state`)
          continue
        }

        formattedChanges[key] = `changed from ${JSON.stringify(value.previous)} to ${JSON.stringify(value.current)}`
      } else {
        // Handle case where value doesn't have the expected structure
        formattedChanges[key] = `changed to ${JSON.stringify(value)}`
      }
    }

    // Skip logging if there are no formatted changes after filtering
    if (Object.keys(formattedChanges).length === 0) {
      console.log("No changes to log after filtering, skipping audit event")
      return
    }

    const { error } = await supabase.from("audit_logs").insert({
      chatbot_id: chatbotId,
      change_by: changeBy,
      change_made: formattedChanges,
    })

    if (error) {
      console.error("Error logging audit event:", error)
    } else {
      console.log("Audit event logged successfully:", formattedChanges)
    }
  } catch (err) {
    console.error("Failed to log audit event:", err)
  }
}
