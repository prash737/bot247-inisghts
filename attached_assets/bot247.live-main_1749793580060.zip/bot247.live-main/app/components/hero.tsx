"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { useState, useEffect } from "react"

const words = ["Intelligence", "Efficiency", "Precision", "Innovation"]
const gradients = [
  "from-blue-600 to-green-600",
  "from-purple-600 to-pink-600",
  "from-orange-600 to-red-600",
  "from-teal-600 to-cyan-600",
]

const illustrations = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/option%201.jpg-c7rFfA9XabUAO2HM9iks9drNlEGG57.jpeg",
    alt: "Three people collaborating with floating icons",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/option%201.jpg-9ITxdM78IAwlpXc4ISsoKbApLSqwp9.jpeg",
    alt: "Two people working with computer interface",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/option%201.jpg-FqttOY6KIS0QvsYQtZfNSyPoaAMceU.jpeg",
    alt: "Video call interface between two people",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/option%201.jpg-9Zstp5nNue81bmROCITBkEMSAWTzps.jpeg",
    alt: "Mobile chat interface with multiple conversations",
  },
]

export function Hero() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [displayText, setDisplayText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const checkAuthStatus = () => {
      const adminData = localStorage.getItem("adminData")
      const userData = localStorage.getItem("userData")
      setIsLoggedIn(!!(adminData || userData))
    }

    checkAuthStatus()
    const interval = setInterval(checkAuthStatus, 1000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    let timer: NodeJS.Timeout

    const animateText = () => {
      const currentWord = words[currentIndex]
      const currentGradient = gradients[currentIndex]

      if (!isDeleting && displayText === currentWord) {
        timer = setTimeout(() => setIsDeleting(true), 3000)
      } else if (isDeleting && displayText === "") {
        setIsDeleting(false)
        setCurrentIndex((prevIndex) => (prevIndex + 1) % words.length)
      } else {
        timer = setTimeout(
          () => {
            setDisplayText(currentWord.substring(0, isDeleting ? displayText.length - 1 : displayText.length + 1))
          },
          isDeleting ? 50 : 100,
        )
      }
    }

    animateText()

    return () => clearTimeout(timer)
  }, [currentIndex, displayText, isDeleting])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden py-20 px-4 md:px-6 lg:px-8">
      {/* Animated Grid Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-white to-green-50/30 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        {/* Main Grid */}
        <div
          className="absolute inset-0 opacity-40 dark:opacity-25"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: "40px 40px",
          }}
        />

        {/* Accent Grid */}
        <div
          className="absolute inset-0 opacity-25 dark:opacity-15"
          style={{
            backgroundImage: `
              linear-gradient(rgba(16, 185, 129, 0.35) 1px, transparent 1px),
              linear-gradient(90deg, rgba(16, 185, 129, 0.35) 1px, transparent 1px)
            `,
            backgroundSize: "120px 120px",
          }}
        />

        {/* Floating Grid Dots */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-blue-500/40 dark:bg-blue-400/25 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            />
          ))}
        </div>

        {/* Gradient Overlays */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full blur-3xl animate-pulse" />
        <div
          className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-tl from-green-400/20 to-transparent rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "1s" }}
        />
        <div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-purple-400/15 to-pink-400/15 rounded-full blur-2xl animate-pulse"
          style={{ animationDelay: "2s" }}
        />

        {/* Animated Lines */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/40 to-transparent animate-pulse" />
          <div
            className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-green-500/40 to-transparent animate-pulse"
            style={{ animationDelay: "1.5s" }}
          />
          <div
            className="absolute left-1/4 top-0 w-px h-full bg-gradient-to-b from-transparent via-purple-500/40 to-transparent animate-pulse"
            style={{ animationDelay: "0.5s" }}
          />
          <div
            className="absolute left-3/4 top-0 w-px h-full bg-gradient-to-b from-transparent via-pink-500/40 to-transparent animate-pulse"
            style={{ animationDelay: "2.5s" }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto flex flex-col lg:flex-row items-center justify-between lg:space-x-20">
        <div className="flex flex-col space-y-10 max-w-2xl mb-10 lg:mb-0 text-center lg:text-left">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-gray-900 dark:text-white">
            Automate With
            <br />
            <span
              className={`text-5xl md:text-7xl bg-gradient-to-r ${gradients[currentIndex]} bg-clip-text text-transparent`}
            >
              {displayText}
            </span>
            <span className="animate-blink">|</span>
          </h1>
          <p className="text-xl text-gray-700 dark:text-gray-300">
            24/7 automated admission support system that streamlines your entire admission process with intelligent
            responses and efficient handling.
          </p>
          {!isLoggedIn && (
            <div className="flex justify-center lg:justify-start">
              <Link href="/signup">
                <Button
                  size="lg"
                  className="bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                >
                  Get Started →
                </Button>
              </Link>
            </div>
          )}
        </div>
        <div className="w-full max-w-2xl lg:max-w-3xl xl:max-w-4xl" aria-hidden="true">
          <div className="relative w-full" style={{ paddingBottom: "75%" }}>
            {illustrations.map((illustration, index) => (
              <div
                key={index}
                className="absolute inset-0 transition-opacity duration-500 ease-in-out"
                style={{ opacity: index === currentIndex ? 1 : 0 }}
              >
                <Image
                  src={illustration.src || "/placeholder.svg"}
                  alt={illustration.alt}
                  fill
                  className="object-contain drop-shadow-2xl"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  priority={index === 0}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
