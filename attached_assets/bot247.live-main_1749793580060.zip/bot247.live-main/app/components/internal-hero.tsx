"use client"

import { useState, useEffect } from "react"

const words = ["Intelligence", "Efficiency", "Precision", "Innovation"]
const gradients = [
  "from-blue-600 to-green-600",
  "from-purple-600 to-pink-600",
  "from-orange-600 to-red-600",
  "from-teal-600 to-cyan-600",
]

export function InternalHero({ title }: { title: string }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [displayText, setDisplayText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    let timer: NodeJS.Timeout

    const animateText = () => {
      const currentWord = words[currentIndex]
      const currentGradient = gradients[currentIndex]

      if (!isDeleting && displayText === currentWord) {
        timer = setTimeout(() => setIsDeleting(true), 3000)
      } else if (isDeleting && displayText === "") {
        setIsDeleting(false)
        setCurrentIndex((prevIndex) => (prevIndex + 1) % words.length)
      } else {
        timer = setTimeout(
          () => {
            setDisplayText(currentWord.substring(0, isDeleting ? displayText.length - 1 : displayText.length + 1))
          },
          isDeleting ? 50 : 100,
        )
      }
    }

    animateText()

    return () => clearTimeout(timer)
  }, [currentIndex, displayText, isDeleting])

  return (
    <section className="py-20 pt-32 bg-gradient-to-br from-blue-500/10 via-green-500/10 to-blue-500/10">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center">{title}</h1>
        <p className="text-xl md:text-2xl text-center mb-8">
          Empowering education with{" "}
          <span className={`bg-gradient-to-r ${gradients[currentIndex]} bg-clip-text text-transparent`}>
            {displayText}
          </span>
          <span className="animate-blink">|</span>
        </p>
      </div>
    </section>
  )
}
