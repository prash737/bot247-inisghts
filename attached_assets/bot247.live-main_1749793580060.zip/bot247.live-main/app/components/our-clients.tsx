"use client"

import Image from "next/image"

const clients = [
  {
    name: "SSCA",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-9F1EvwQ1BSTv4WE2Z32Z5IjRJ7Zr2s.png",
    alt: "SSCA Logo",
  },
  {
    name: "SSBS",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-Y4RW6cdWANAk1lP4Q8hWgHETES4yf9.png",
    alt: "SSBS Logo",
  },
  {
    name: "SIBM BENGALURU",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-ErLBJ4khHvcq8qwM3GD08JQ7gQCp2N.png",
    alt: "SIBM BENGALURU Logo",
  },
  {
    name: "SIMS",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-5XRe78uatw4VPZ0fv7eTUPFUOHdmmH.png",
    alt: "SIMS Logo",
  },
  {
    name: "SCMS-B",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-VfNtztAfBqtcREtqvJdxK5N4MvJqqo.png",
    alt: "SCMS-B Logo",
  },
  {
    name: "SSODL",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-xEODQ5swAHXCHUnlMknIcYFmdmQZFf.png",
    alt: "SSODL Logo",
  },
]

export function OurClients() {
  return (
    <section id="our-clients" className="py-24 bg-white dark:bg-gray-900 w-full">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white">Our Clients</h2>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center justify-items-center">
          {clients.map((client, index) => (
            <div key={index} className="w-full flex items-center justify-center">
              <div className="relative w-full h-24 md:h-32">
                <Image
                  src={client.logo || "/placeholder.svg"}
                  alt={client.alt}
                  fill
                  className="object-contain transition-all duration-300 filter grayscale hover:grayscale-0"
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
