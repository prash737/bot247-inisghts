import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "How does bot247.live help educational institutions?",
    answer:
      "Bot247.live provides 24/7 automated support for admissions, handling routine queries, document processing, and providing instant responses to student inquiries, significantly reducing administrative workload.",
  },
  {
    question: "What types of queries can the chatbot handle?",
    answer:
      "Our chatbot can handle a wide range of queries including admission requirements, application status, document submissions, deadlines, fee structures, and course information.",
  },
  {
    question: "Is bot247.live secure for handling student information?",
    answer:
      "Yes, we implement enterprise-grade security measures including encryption, secure data storage, and compliance with educational data protection regulations.",
  },
  {
    question: "How many languages does bot247.live support?",
    answer:
      "Bot247.live supports over 150 languages, making it accessible to international students and institutions worldwide.",
  },
  {
    question: "What kind of analytics and reporting does bot247.live provide?",
    answer:
      "We provide comprehensive analytics including query patterns, response times, user satisfaction rates, and detailed insights into admission trends and bottlenecks.",
  },
]

export function FAQ() {
  return (
    <section id="faq" className="py-20 bg-gradient-to-br from-blue-500/5 via-green-500/5 to-blue-500/5 w-full">
      <div className="container mx-auto px-4 md:px-6 lg:px-8 space-y-12">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
          Frequently Asked Questions
        </h2>
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border-b border-gray-200 dark:border-gray-700"
              >
                <AccordionTrigger className="text-gray-900 dark:text-white">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-gray-600 dark:text-gray-300">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
