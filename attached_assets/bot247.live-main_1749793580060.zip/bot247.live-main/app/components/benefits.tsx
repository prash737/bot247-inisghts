import { Building2, Users, UserCog } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"

const benefits = [
  {
    icon: Building2,
    title: "For Institutions",
    features: [
      "Reduced administrative overhead",
      "Improved admission efficiency",
      "Better resource allocation",
      "Advanced data-driven decisions",
      "Increased global reach",
    ],
  },
  {
    icon: Users,
    title: "For Students/Parents",
    features: [
      "Instant responses 24/7",
      "Multilingual support",
      "Clear application tracking",
      "Simplified documentation",
      "Reduced waiting times",
    ],
  },
  {
    icon: UserCog,
    title: "For Administrative Staff",
    features: [
      "Automated routine tasks",
      "Focus on complex cases",
      "Organized documentation",
      "Real-time reporting",
      "Reduced workload",
    ],
  },
]

export function Benefits() {
  return (
    <section
      id="benefits"
      className="py-20 bg-gradient-to-br from-blue-50 to-green-50 dark:from-blue-900/10 dark:to-green-900/10 w-full"
    >
      <div className="container mx-auto px-4 md:px-6 lg:px-8 space-y-12">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
          Benefits for All Stakeholders
        </h2>
        <div className="grid md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <Card
              key={index}
              className="border border-gray-200 dark:border-gray-700 shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white dark:bg-gray-800"
            >
              <CardHeader>
                <div className="p-3 w-fit bg-blue-100 dark:bg-blue-900 rounded-full mb-4">
                  <benefit.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">{benefit.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {benefit.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-2">
                      <Check className="w-5 h-5 text-green-500 dark:text-green-400 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
