"use client"

import { Button } from "@/components/ui/button"
import { Menu, X, User, ArrowLeft, LogOut } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState, useEffect, useCallback } from "react"
import { usePathname } from "next/navigation"
import { useRouter } from "next/navigation"
import { createClient } from "@supabase/supabase-js"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useScrollToHash } from "../hooks/useScrollToHash"
import { scrollToSection } from "../utils/scrollToSection"
import { useToast } from "@/components/ui/use-toast"
import type React from "react"

// Initialize Supabase client
const supabase = createClient(
  "https://zsivtypgrrcttzhtfjsf.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpzaXZ0eXBncnJjdHR6aHRmanNmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzgzMzU5NTUsImV4cCI6MjA1MzkxMTk1NX0.3cAMZ4LPTqgIc8z6D8LRkbZvEhP_ffI3Wka0-QDSIys",
)

export function Nav() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [username, setUsername] = useState("")
  const [chatbotStatus, setChatbotStatus] = useState<string>("Inactive")
  const [isLoggingOut, setIsLoggingOut] = useState(false)
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const router = useRouter()
  const { toast } = useToast()
  const isAdminRoute = pathname === "/admin/login" || pathname.startsWith("/admin")

  useScrollToHash()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const checkAuthStatus = useCallback(() => {
    try {
      const adminData = localStorage.getItem("adminData")
      const userData = localStorage.getItem("userData")

      // Reset states first
      setIsLoggedIn(false)
      setIsAdmin(false)
      setUsername("")

      if (adminData) {
        try {
          const parsedAdminData = JSON.parse(adminData)
          console.log("Admin data found:", parsedAdminData) // Debug log
          if (parsedAdminData && parsedAdminData.username) {
            setIsLoggedIn(true)
            setIsAdmin(true)
            setUsername(parsedAdminData.username)
            console.log("Admin authenticated:", parsedAdminData.username) // Debug log
          }
        } catch (error) {
          console.error("Error parsing admin data:", error)
          localStorage.removeItem("adminData")
        }
      } else if (userData) {
        try {
          const parsedUserData = JSON.parse(userData)
          console.log("User data found:", parsedUserData) // Debug log
          if (parsedUserData && parsedUserData.username) {
            setIsLoggedIn(true)
            setIsAdmin(false)
            setUsername(parsedUserData.username)

            if (parsedUserData.chatbotId) {
              supabase
                .from("credentials")
                .select("chatbot_status")
                .eq("chatbot_id", parsedUserData.chatbotId)
                .single()
                .then(({ data, error }) => {
                  if (data && !error) {
                    setChatbotStatus(data.chatbot_status)
                  }
                })
                .catch((error) => {
                  console.error("Error fetching chatbot status:", error)
                })
            }
          }
        } catch (error) {
          console.error("Error parsing user data:", error)
          localStorage.removeItem("userData")
        }
      }
    } catch (error) {
      console.error("Error in checkAuthStatus:", error)
    }
  }, [])

  useEffect(() => {
    setMounted(true)
    checkAuthStatus()

    // Check auth status periodically to ensure consistency
    const interval = setInterval(checkAuthStatus, 1000)

    // Listen for storage changes
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "adminData" || e.key === "userData") {
        checkAuthStatus()
      }
    }

    window.addEventListener("storage", handleStorageChange)

    return () => {
      clearInterval(interval)
      window.removeEventListener("storage", handleStorageChange)
    }
  }, [checkAuthStatus])

  const toggleMenu = useCallback(() => setIsMenuOpen((prev) => !prev), [])

  const navItems = isAdmin
    ? [{ name: "Admin Dashboard", href: "/admin" }]
    : [
        { name: "Profile", href: "/user-profile" },
        { name: "Dashboard", href: "/dashboard", disabled: chatbotStatus === "Inactive" },
        { name: "Conversations", href: "/conversations" },
      ]

  const publicNavItems = [
    { name: "Features", href: "#features" },
    { name: "Benefits", href: "#benefits" },
    { name: "Clients", href: "#our-clients" },
    { name: "Pricing", href: "#pricing" },
    { name: "FAQ", href: "#faq" },
  ]

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>, href: string) => {
    e.preventDefault()
    if (pathname === "/") {
      const targetId = href.replace("#", "")
      scrollToSection(targetId)
    } else {
      router.push(`/${href}`)
    }
    setIsMenuOpen(false)
  }

  const handleLogout = async () => {
    if (isLoggingOut) return

    setIsLoggingOut(true)

    try {
      // Call logout API endpoint
      try {
        const response = await fetch("/api/auth/logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        })

        if (!response.ok) {
          console.warn("Logout API call failed with status:", response.status)
        }
      } catch (apiError) {
        console.warn("Logout API call failed:", apiError)
      }

      // Clear all session data
      if (isAdmin) {
        localStorage.removeItem("adminData")
        localStorage.removeItem("adminThemeSettings")
      } else {
        localStorage.removeItem("userData")
      }

      sessionStorage.clear()

      // Update state immediately
      setIsLoggedIn(false)
      setIsAdmin(false)
      setUsername("")
      setIsMenuOpen(false)

      // Show success message
      toast({
        title: "Logged out successfully",
        description: "You have been logged out successfully",
      })

      // Redirect based on current route
      if (isAdminRoute) {
        router.push("/admin/login")
      } else {
        router.push("/")
      }
    } catch (error) {
      console.error("Logout error:", error)

      // Force cleanup even on error
      try {
        localStorage.removeItem("adminData")
        localStorage.removeItem("userData")
        localStorage.removeItem("adminThemeSettings")
        sessionStorage.clear()
      } catch (storageError) {
        console.error("Error clearing storage:", storageError)
      }

      setIsLoggedIn(false)
      setIsAdmin(false)
      setUsername("")
      setIsMenuOpen(false)

      toast({
        title: "Logout completed",
        description: "You have been logged out",
        variant: "destructive",
      })

      if (isAdminRoute) {
        router.push("/admin/login")
      } else {
        router.push("/")
      }
    } finally {
      setIsLoggingOut(false)
    }
  }

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (isMenuOpen && !event.target?.closest("[data-navbar]")) {
        setIsMenuOpen(false)
      }
    }

    document.addEventListener("click", handleOutsideClick)
    return () => document.removeEventListener("click", handleOutsideClick)
  }, [isMenuOpen])

  if (!mounted) {
    return null
  }

  // Debug log for current state
  console.log("Current auth state:", { isLoggedIn, isAdmin, username, isAdminRoute })

  return (
    <nav
      data-navbar
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/80 dark:bg-gray-900/80 backdrop-blur-md shadow-md" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <Link href={isAdminRoute ? "/admin" : "/"} className="flex-shrink-0">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/light-mode-2dwbwhgslATazwB8fbciP1wTk39sXe.svg"
                alt="Bot247 Logo"
                width={isScrolled ? 140 : 180}
                height={isScrolled ? 46 : 60}
                className={`transition-all duration-300 ${isScrolled ? "h-[46px]" : "h-[60px]"} w-auto`}
              />
            </Link>
            {isAdminRoute && (
              <div className="text-lg font-semibold text-blue-600 dark:text-blue-400 ml-4 flex items-center">
                <span className="hidden sm:inline-block border-l border-gray-300 dark:border-gray-700 h-6 mx-3"></span>
                <span>Admin Panel</span>
              </div>
            )}
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            {isAdminRoute ? (
              // Admin route navigation - Always show logout if on admin route and logged in
              isLoggedIn ? (
                <>
                  <span className="text-sm text-gray-600 dark:text-gray-400">Welcome, {username || "Admin"}</span>
                  <Button
                    onClick={handleLogout}
                    variant="destructive"
                    size="sm"
                    disabled={isLoggingOut}
                    className="flex items-center space-x-2"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>{isLoggingOut ? "Logging out..." : "Logout"}</span>
                  </Button>
                </>
              ) : null
            ) : (
              // Regular routes navigation
              <>
                <div className="flex items-baseline space-x-4">
                  {isLoggedIn
                    ? navItems.map((item) => (
                        <Link
                          key={item.name}
                          href={item.disabled ? "#" : item.href}
                          className={`px-3 py-2 rounded-md text-sm font-medium ${
                            pathname === item.href
                              ? "text-blue-600 dark:text-blue-400"
                              : "text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                          } ${item.disabled ? "opacity-50 cursor-not-allowed" : ""}`}
                          onClick={(e) => {
                            if (item.disabled) {
                              e.preventDefault()
                            }
                          }}
                        >
                          {item.name}
                        </Link>
                      ))
                    : publicNavItems.map((item) => (
                        <button
                          key={item.name}
                          onClick={(e) => handleNavClick(e, item.href)}
                          className="px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                        >
                          {item.name}
                        </button>
                      ))}
                </div>
                <div className="flex items-center ml-6">
                  {isLoggedIn ? (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                          <User className="h-5 w-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem className="font-medium">Signed in as {username}</DropdownMenuItem>
                        {isAdmin ? (
                          <DropdownMenuItem>
                            <Link href="/admin" className="w-full">
                              Admin Dashboard
                            </Link>
                          </DropdownMenuItem>
                        ) : (
                          <>
                            <DropdownMenuItem>
                              <Link href="/user-profile" className="w-full">
                                Profile
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Link href="/dashboard" className="w-full">
                                Dashboard
                              </Link>
                            </DropdownMenuItem>
                          </>
                        )}
                        <DropdownMenuItem
                          onClick={handleLogout}
                          disabled={isLoggingOut}
                          className="text-red-600 focus:text-red-600"
                        >
                          {isLoggingOut ? "Logging out..." : "Log out"}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : (
                    <>
                      <Link href="/login">
                        <Button variant="ghost" className="ml-4">
                          Log in
                        </Button>
                      </Link>
                      <Link href="/signup">
                        <Button className="ml-4">Sign up</Button>
                      </Link>
                    </>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden ml-auto">
            <Button variant="ghost" onClick={toggleMenu} aria-expanded={isMenuOpen}>
              <span className="sr-only">Toggle menu</span>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/20 backdrop-blur-sm" onClick={(e) => e.stopPropagation()}>
          <div className="fixed inset-y-0 right-0 w-full max-w-sm bg-white dark:bg-gray-900 shadow-lg flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
              <Button
                variant="ghost"
                onClick={() => {
                  setIsMenuOpen(false)
                  router.push(isAdminRoute ? "/admin" : "/")
                }}
                className="p-2"
              >
                <ArrowLeft className="h-6 w-6" />
                <span className="sr-only">Back to Home</span>
              </Button>
              <Button variant="ghost" onClick={() => setIsMenuOpen(false)} className="p-2">
                <X className="h-6 w-6" />
                <span className="sr-only">Close menu</span>
              </Button>
            </div>

            <div className="flex-grow overflow-y-auto p-4">
              <div className="space-y-2">
                {isAdminRoute ? (
                  isLoggedIn ? (
                    <div className="space-y-4">
                      <div className="text-xl font-bold mb-4 text-center">Admin Panel</div>
                      <div className="text-center text-sm text-gray-600 dark:text-gray-400 mb-4">
                        Welcome, {username || "Admin"}
                      </div>
                      <Button
                        onClick={handleLogout}
                        variant="destructive"
                        size="sm"
                        disabled={isLoggingOut}
                        className="w-full flex items-center justify-center space-x-2"
                      >
                        <LogOut className="h-4 w-4" />
                        <span>{isLoggingOut ? "Logging out..." : "Logout"}</span>
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Please log in to access admin panel</p>
                    </div>
                  )
                ) : isLoggedIn ? (
                  navItems.map((item) => (
                    <Link
                      key={item.name}
                      href={item.disabled ? "#" : item.href}
                      className={`block px-3 py-2 rounded-md text-base font-medium ${
                        pathname === item.href
                          ? "text-blue-600 dark:text-blue-400"
                          : "text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                      } ${item.disabled ? "opacity-50 cursor-not-allowed" : ""}`}
                      onClick={(e) => {
                        if (item.disabled) {
                          e.preventDefault()
                        } else {
                          setIsMenuOpen(false)
                        }
                      }}
                    >
                      {item.name}
                    </Link>
                  ))
                ) : (
                  publicNavItems.map((item) => (
                    <button
                      key={item.name}
                      onClick={(e) => handleNavClick(e, item.href)}
                      className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                    >
                      {item.name}
                    </button>
                  ))
                )}
              </div>

              {!isAdminRoute && (
                <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex flex-col space-y-4">
                    {isLoggedIn ? (
                      <>
                        <div className="flex items-center space-x-3 px-3 py-2">
                          <User className="h-6 w-6" />
                          <span className="text-base font-medium">{username}</span>
                        </div>
                        <Button
                          onClick={handleLogout}
                          variant="ghost"
                          disabled={isLoggingOut}
                          className="justify-start px-3 py-2 text-red-600 hover:text-red-700"
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          {isLoggingOut ? "Logging out..." : "Log out"}
                        </Button>
                      </>
                    ) : (
                      <>
                        <Link
                          href="/login"
                          className="px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                          onClick={() => setIsMenuOpen(false)}
                        >
                          Log in
                        </Link>
                        <Link
                          href="/signup"
                          className="px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-blue-600 dark:text-gray-300 dark:hover:text-blue-400"
                          onClick={() => setIsMenuOpen(false)}
                        >
                          Sign up
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
