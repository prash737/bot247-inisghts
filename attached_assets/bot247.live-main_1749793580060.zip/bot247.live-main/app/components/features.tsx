import { HelpCircle, Zap, Languages, Database, BarChart3, MessageCircle } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const features = [
  {
    icon: HelpCircle,
    title: "24/7 Support",
    description: "Round-the-clock assistance for all your admission queries.",
  },
  {
    icon: Zap,
    title: "Instant Responses",
    description: "Get immediate answers to your questions without waiting.",
  },
  {
    icon: Languages,
    title: "Multilingual",
    description: "Support in multiple languages for global accessibility.",
  },
  {
    icon: Database,
    title: "Data Integration",
    description: "Seamlessly integrates with your existing admission systems.",
  },
  {
    icon: BarChart3,
    title: "Analytics",
    description: "Gain insights into admission trends and student behavior.",
  },
  {
    icon: MessageCircle,
    title: "Personalized Interaction",
    description: "Tailored responses based on individual student profiles.",
  },
]

export function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50 dark:bg-gray-900 w-full">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <CardContent className="p-6">
                <feature.icon className="w-12 h-12 text-blue-500 mb-4" />
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
