# Bot247 User Manual - Troubleshooting and FAQs

## Common Issues and Solutions

This section addresses frequently encountered issues and provides step-by-step solutions to help you resolve them quickly.

## Chatbot Performance Issues

### Chatbot Not Responding

If your chatbot fails to respond to user queries:

1. **Check Activation Status**: Verify that your chatbot is activated in the dashboard.
2. **Verify Embedding**: Ensure the embedding code is correctly placed in your website's HTML.
3. **Network Issues**: Check your website's console for network errors.
4. **Server Status**: Visit [status.bot247.live](https://status.bot247.live) to check if there are any ongoing service disruptions.

**Solution**: If the issue persists, try regenerating your embed code and replacing it on your website.

### Incorrect or Irrelevant Responses

If your chatbot provides inaccurate answers:

1. **Review Knowledge Base**: Check if the correct information exists in your knowledge base.
2. **Check for Conflicts**: Look for contradictory information in your knowledge base.
3. **Verify Training**: Ensure your chatbot has been trained after recent knowledge base updates.

**Solution**: Update your knowledge base with correct information and retrain your chatbot.

### Slow Response Times

If your chatbot takes too long to respond:

1. **Check Internet Connection**: Verify your connection speed.
2. **Server Load**: High traffic might cause temporary slowdowns.
3. **Knowledge Base Size**: Very large knowledge bases may increase processing time.

**Solution**: Consider optimizing your knowledge base by removing redundant information or splitting it into more focused categories.

## Account and Billing Issues

### Payment Failure

If your payment method is declined:

1. **Card Details**: Verify that your card information is current and correct.
2. **Expiration Date**: Check if your card has expired.
3. **Sufficient Funds**: Ensure your account has sufficient funds.
4. **Bank Restrictions**: Some banks may block recurring payments or international transactions.

**Solution**: Update your payment method in the Billing section of your account settings.

### Subscription Changes Not Applied

If changes to your subscription aren't reflected:

1. **Confirmation**: Check if you received a confirmation email.
2. **Pending Status**: Some changes may take up to 24 hours to process.
3. **Payment Issues**: Verify that any required payments were successful.

**Solution**: Contact support with your confirmation details if the issue persists beyond 24 hours.

### Unable to Access Premium Features

If you can't access features included in your plan:

1. **Plan Verification**: Confirm your current subscription plan in account settings.
2. **Account Status**: Check if your account is in good standing.
3. **Browser Cache**: Clear your browser cache and cookies.

**Solution**: Log out and log back in to refresh your session, or contact support if the issue persists.

## Technical Issues

### Embedding Problems

If you're having trouble embedding your chatbot:

1. **Code Placement**: Ensure the code is placed just before the closing `</body>` tag.
2. **Script Conflicts**: Check for conflicts with other JavaScript on your page.
3. **Content Security Policy**: Verify your website's CSP allows scripts from bot247.live.

**Solution**: Try using the alternative embedding method provided in the embed options.

### Mobile Display Issues

If your chatbot doesn't display correctly on mobile devices:

1. **Responsive Design**: Check if your website is properly optimized for mobile.
2. **Viewport Settings**: Ensure your website has the correct viewport meta tag.
3. **Mobile Preview**: Use the mobile preview in the embed settings to test appearance.

**Solution**: Adjust the mobile-specific settings in the embed options.

### Browser Compatibility

If your chatbot works in some browsers but not others:

1. **Browser Support**: Bot247 supports Chrome, Firefox, Safari, and Edge (latest versions).
2. **JavaScript Enabled**: Verify that JavaScript is enabled in the browser.
3. **Privacy Settings**: Check if privacy settings or extensions are blocking the chatbot.

**Solution**: Provide browser-specific instructions to users or add a compatibility notice on your website.

## Knowledge Base Issues

### Failed File Uploads

If you can't upload files to your knowledge base:

1. **File Format**: Ensure your file is in a supported format (PDF, DOCX, TXT, CSV).
2. **File Size**: Check if the file exceeds the size limit (typically 10MB).
3. **File Content**: Make sure the file isn't password-protected or corrupted.

**Solution**: Try converting the file to a different format or splitting large files into smaller ones.

### Website Crawl Not Working

If the website crawler isn't extracting information correctly:

1. **URL Format**: Verify that the URL is correctly formatted and accessible.
2. **Website Structure**: Some websites with complex JavaScript may be difficult to crawl.
3. **Access Restrictions**: Check if the website has robots.txt restrictions.

**Solution**: Try crawling specific pages rather than the entire site, or manually add the most important information.

### Knowledge Base Not Updating

If changes to your knowledge base aren't reflected in chatbot responses:

1. **Training Status**: Verify that you've trained the chatbot after making changes.
2. **Processing Time**: Large updates may take time to process.
3. **Cache Issues**: Users might be seeing cached responses.

**Solution**: Manually trigger training in the knowledge base section and wait for confirmation of completion.

## Analytics and Reporting Issues

### Missing Data

If analytics data appears incomplete:

1. **Date Range**: Check if the correct date range is selected.
2. **Processing Delay**: Recent data may take up to 24 hours to appear.
3. **Tracking Issues**: Verify that the chatbot is properly embedded on all pages.

**Solution**: Adjust the date range or wait for data processing to complete.

### Export Failures

If you can't export reports or data:

1. **File Size**: Very large exports may time out.
2. **Browser Issues**: Try using a different browser.
3. **Network Stability**: Ensure you have a stable internet connection.

**Solution**: Try exporting smaller date ranges or specific sections rather than all data at once.

## Frequently Asked Questions

### General Questions

**Q: How many chatbots can I create with my subscription?**
A: The Basic plan includes one chatbot. Pro and Advanced plans include additional chatbots, and you can purchase more as needed.

**Q: Can I transfer my chatbot to another account?**
A: Yes, contact support to arrange a transfer between accounts.

**Q: Is Bot247 GDPR compliant?**
A: Yes, Bot247 is fully GDPR compliant. You can access our Data Processing Agreement in the account settings.

**Q: Can I use Bot247 in languages other than English?**
A: Yes, Bot247 supports over 150 languages for both the interface and chatbot responses.

### Knowledge Base Questions

**Q: How much information can I add to my knowledge base?**
A: The Basic plan supports up to 100 pages of content. Pro and Advanced plans support up to 1,000 pages.

**Q: How often should I update my knowledge base?**
A: We recommend reviewing and updating your knowledge base at least monthly, and immediately when important information changes (like application deadlines).

**Q: Can I import FAQs from an existing database?**
A: Yes, you can import FAQs using our CSV template or API integration.

### Technical Questions

**Q: Does Bot247 work with single-page applications (SPAs)?**
A: Yes, Bot247 is compatible with SPAs built with frameworks like React, Angular, or Vue.

**Q: Can I customize the chatbot beyond the provided options?**
A: Advanced plan users can access custom CSS and JavaScript options for deeper customization.

**Q: Is there an API available?**
A: Yes, Pro and Advanced plans include API access for integration with other systems.

### Billing Questions

**Q: Can I switch between monthly and annual billing?**
A: Yes, you can switch at any time. Annual billing includes a 10% discount.

**Q: What happens if I exceed my plan's conversation limit?**
A: You'll receive a notification when you reach 80% of your limit. If you exceed the limit, you can upgrade your plan or purchase additional conversations.

**Q: Do you offer refunds?**
A: We offer a 14-day money-back guarantee for new subscriptions. After that period, we do not provide refunds for partial months.

## Contacting Support

If you can't find a solution to your issue:

1. **Email Support**: Contact support@bot247.live with details of your issue.
2. **Live Chat**: Available on our website during business hours (9 AM - 6 PM IST, Monday-Friday).
3. **Support Ticket**: Submit a ticket through your account's support section for tracking.

When contacting support, please include:
- Your account email
- Chatbot ID (found in your dashboard)
- Detailed description of the issue
- Screenshots or error messages
- Steps you've already taken to resolve the issue

## Feedback and Feature Requests

We continuously improve Bot247 based on user feedback:

1. **Feedback Form**: Access the feedback form in your dashboard under "Help & Feedback".
2. **Feature Requests**: Submit specific feature requests through the same form.
3. **Beta Program**: Join our beta program to test new features before they're released.

Your input helps us make Bot247 better for everyone!
