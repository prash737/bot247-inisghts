# Bot247 User Manual - Account Management and Billing

## Introduction to Account Management

Effective account management ensures your Bot247 experience remains smooth and aligned with your institution's needs. This section covers managing your profile, team members, subscription plans, and billing information.

## Accessing Account Settings

To access your account settings:

1. Log in to your Bot247 dashboard
2. Click on your profile icon in the top-right corner
3. Select "Profile" from the dropdown menu

## Profile Management

### Personal Information

Update your personal details:

1. Navigate to the "Profile" tab
2. Edit your name, email, and contact information
3. Upload or change your profile picture
4. Click "Save Changes"

### Security Settings

Manage your account security:

1. Navigate to the "Security" tab
2. Change your password
3. Enable/disable two-factor authentication
4. View recent login activity
5. Manage connected devices

### Notification Preferences

Control how and when you receive notifications:

1. Navigate to the "Notifications" tab
2. Configure email notification settings
3. Set up dashboard notification preferences
4. Enable/disable mobile push notifications (if using the mobile app)
5. Click "Save Preferences"

## Team Management (Pro and Advanced Plans)

For institutions with multiple users:

### Adding Team Members

1. Navigate to "Team" in the account settings
2. Click "Add Team Member"
3. Enter the team member's email address
4. Select their role:
   - **Admin**: Full access to all features
   - **Editor**: Can modify chatbot settings and knowledge base
   - **Viewer**: Can view analytics and conversations but cannot make changes
   - **Support**: Can view and respond to conversations
5. Click "Send Invitation"

### Managing Team Permissions

1. Navigate to "Team" in the account settings
2. Click on a team member's name
3. Adjust their role and permissions
4. Set access restrictions if needed
5. Click "Save Changes"

### Removing Team Members

1. Navigate to "Team" in the account settings
2. Find the team member you want to remove
3. Click the "Remove" button
4. Confirm the removal

## Subscription Management

### Viewing Current Plan

1. Navigate to "Subscription" in the account settings
2. View your current plan details:
   - Plan name
   - Monthly/annual cost
   - Renewal date
   - Usage limits and current usage
   - Features included

### Changing Plans

To upgrade or downgrade your subscription:

1. Navigate to "Subscription" in the account settings
2. Click "Change Plan"
3. Select your desired plan
4. Review the changes in features and pricing
5. Click "Confirm Change"
6. Complete the payment process if upgrading

**Note**: Plan changes take effect immediately. When upgrading, you'll be charged the prorated difference for the remainder of your billing cycle. When downgrading, you'll receive credit toward future billing.

### Adding Chatbots (Pro and Advanced Plans)

If you need additional chatbots:

1. Navigate to "Subscription" in the account settings
2. Click "Add Chatbot"
3. Select the number of additional chatbots
4. Review the additional cost
5. Click "Confirm" and complete the payment

## Billing Management

### Payment Methods

Manage your payment information:

1. Navigate to "Billing" in the account settings
2. View your current payment method
3. Add a new payment method:
   - Credit/debit card
   - Bank account (where available)
4. Set a default payment method
5. Remove outdated payment methods

### Invoices and Receipts

Access your billing history:

1. Navigate to "Billing" in the account settings
2. View a list of all invoices
3. Download PDF receipts
4. Request invoice corrections if needed

### Billing Information

Update your billing details:

1. Navigate to "Billing" in the account settings
2. Click "Edit Billing Information"
3. Update your:
   - Billing address
   - Tax ID/GST number
   - Billing email
   - Purchase order number (if applicable)
4. Click "Save Changes"

## Account Cancellation

If you need to cancel your Bot247 subscription:

1. Navigate to "Subscription" in the account settings
2. Click "Cancel Subscription"
3. Select a reason for cancellation (helps us improve)
4. Choose whether to:
   - Cancel immediately
   - Cancel at the end of the billing cycle
5. Confirm cancellation

**Note**: After cancellation, your data will be retained for 30 days, after which it will be permanently deleted. You can reactivate your account during this period to restore access.

## Data Export

Before cancellation or for backup purposes:

1. Navigate to "Account" in the account settings
2. Click "Export Data"
3. Select what data to export:
   - Chatbot configurations
   - Knowledge base
   - Conversation history
   - Analytics
4. Click "Generate Export"
5. Download the exported data when ready

## Account Support

For account-related assistance:

1. Navigate to "Support" in the account settings
2. Browse the FAQ section for common questions
3. Submit a support ticket:
   - Select the issue category
   - Provide a detailed description
   - Attach screenshots if relevant
   - Submit the ticket
4. Track the status of your support requests

## Billing FAQs

### Common Billing Questions

**Q: When am I charged for my subscription?**
A: Your subscription is billed on the same day each month, based on your initial signup date.

**Q: Can I get a refund if I cancel mid-month?**
A: Bot247 does not provide prorated refunds for partial months. Your subscription remains active until the end of your billing cycle.

**Q: Do you offer educational discounts?**
A: Yes, we offer special pricing for educational institutions. Contact our sales team at sales@bot247.live for details.

**Q: Can I change from monthly to annual billing?**
A: Yes, you can switch to annual billing at any time. Annual plans include a 10% discount compared to monthly billing.

## Best Practices for Account Management

1. **Regular Audits**: Review team members and permissions quarterly.

2. **Usage Monitoring**: Keep an eye on your usage metrics to ensure your plan meets your needs.

3. **Backup Data**: Periodically export your data for safekeeping.

4. **Update Information**: Keep your billing and contact information current.

5. **Security Checks**: Regularly update passwords and review login activity.

## Troubleshooting

### Common Account Issues

1. **Login Problems**: If you can't log in, use the "Forgot Password" option or contact support.

2. **Payment Failures**: If a payment fails, verify your payment method details and try again.

3. **Permission Errors**: If team members can't access certain features, check their assigned roles.

For additional help, contact Bot247 support at support@bot247.live.

## Next Steps

If you encounter any issues or have questions not covered in this manual, refer to the Troubleshooting and FAQs section next.
