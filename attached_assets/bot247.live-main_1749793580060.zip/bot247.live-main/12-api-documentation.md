# Bot247 User Manual - API Documentation

## Introduction to the Bot247 API

The Bot247 API allows developers to programmatically interact with the platform, enabling custom integrations, automations, and extensions. This section provides comprehensive documentation for using the API effectively.

**Note**: API access is available exclusively to Pro and Advanced plan subscribers.

## Getting Started

### Authentication

All API requests require authentication using an API key:

1. Generate an API key in your Bot247 dashboard:
   - Navigate to "Settings" > "API"
   - Click "Generate New API Key"
   - Name your key (e.g., "Website Integration")
   - Set permissions as needed
   - Click "Create"

2. Include your API key in all requests:
   - As a header: `Authorization: Bearer YOUR_API_KEY`
   - Or as a query parameter: `?api_key=YOUR_API_KEY`

### Base URL

All API endpoints are relative to the base URL:

\`\`\`
https://api.bot247.live/v1
\`\`\`

### Response Format

All API responses are in JSON format and include:

- `status`: Success or error
- `data`: The requested data (if successful)
- `error`: Error details (if unsuccessful)
- `meta`: Pagination and other metadata

## Core Endpoints

### Chatbot Management

#### List Chatbots

\`\`\`
GET /chatbots
\`\`\`

Returns a list of all chatbots associated with your account.

**Parameters:**
- `limit` (optional): Number of results per page (default: 20)
- `offset` (optional): Pagination offset (default: 0)

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": [
    {
      "id": "cb_123456789",
      "name": "Admissions Assistant",
      "status": "active",
      "created_at": "2023-05-15T10:30:00Z",
      "updated_at": "2023-06-20T14:45:00Z"
    },
    {
      "id": "cb_987654321",
      "name": "Financial Aid Helper",
      "status": "inactive",
      "created_at": "2023-06-01T09:15:00Z",
      "updated_at": "2023-06-01T09:15:00Z"
    }
  ],
  "meta": {
    "total": 2,
    "limit": 20,
    "offset": 0
  }
}
\`\`\`

#### Get Chatbot Details

\`\`\`
GET /chatbots/{chatbot_id}
\`\`\`

Returns detailed information about a specific chatbot.

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "id": "cb_123456789",
    "name": "Admissions Assistant",
    "status": "active",
    "created_at": "2023-05-15T10:30:00Z",
    "updated_at": "2023-06-20T14:45:00Z",
    "theme": {
      "primary_color": "#3B82F6",
      "secondary_color": "#10B981",
      "border_radius": 8,
      "dark_mode": false
    },
    "settings": {
      "greeting": "Hello! How can I help you with admissions today?",
      "response_tone": "friendly",
      "response_length": "concise"
    },
    "stats": {
      "total_conversations": 1245,
      "total_queries": 5678
    }
  }
}
\`\`\`

#### Update Chatbot

\`\`\`
PATCH /chatbots/{chatbot_id}
\`\`\`

Updates a specific chatbot's settings.

**Request Body:**
\`\`\`json
{
  "name": "Updated Chatbot Name",
  "theme": {
    "primary_color": "#4F46E5",
    "secondary_color": "#10B981"
  },
  "settings": {
    "greeting": "Welcome! How can I assist you today?"
  }
}
\`\`\`

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "id": "cb_123456789",
    "name": "Updated Chatbot Name",
    "updated_at": "2023-07-01T11:22:33Z"
  }
}
\`\`\`

### Knowledge Base Management

#### List Knowledge Base Entries

\`\`\`
GET /chatbots/{chatbot_id}/knowledge
\`\`\`

Returns knowledge base entries for a specific chatbot.

**Parameters:**
- `limit` (optional): Number of results per page (default: 20)
- `offset` (optional): Pagination offset (default: 0)
- `category` (optional): Filter by category
- `query` (optional): Search for specific content

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": [
    {
      "id": "kb_123456",
      "question": "What are the admission requirements?",
      "answer": "Our admission requirements include...",
      "category": "Admissions",
      "created_at": "2023-05-20T10:30:00Z"
    },
    {
      "id": "kb_789012",
      "question": "When is the application deadline?",
      "answer": "The application deadline for the fall semester is...",
      "category": "Deadlines",
      "created_at": "2023-05-21T14:45:00Z"
    }
  ],
  "meta": {
    "total": 156,
    "limit": 20,
    "offset": 0
  }
}
\`\`\`

#### Add Knowledge Base Entry

\`\`\`
POST /chatbots/{chatbot_id}/knowledge
\`\`\`

Adds a new entry to the knowledge base.

**Request Body:**
\`\`\`json
{
  "question": "How do I apply for financial aid?",
  "answer": "To apply for financial aid, you need to complete the FAFSA form...",
  "category": "Financial Aid"
}
\`\`\`

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "id": "kb_345678",
    "question": "How do I apply for financial aid?",
    "answer": "To apply for financial aid, you need to complete the FAFSA form...",
    "category": "Financial Aid",
    "created_at": "2023-07-01T15:30:00Z"
  }
}
\`\`\`

#### Update Knowledge Base Entry

\`\`\`
PATCH /chatbots/{chatbot_id}/knowledge/{entry_id}
\`\`\`

Updates an existing knowledge base entry.

**Request Body:**
\`\`\`json
{
  "answer": "Updated answer with more detailed information..."
}
\`\`\`

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "id": "kb_345678",
    "question": "How do I apply for financial aid?",
    "answer": "Updated answer with more detailed information...",
    "category": "Financial Aid",
    "updated_at": "2023-07-02T09:15:00Z"
  }
}
\`\`\`

#### Delete Knowledge Base Entry

\`\`\`
DELETE /chatbots/{chatbot_id}/knowledge/{entry_id}
\`\`\`

Removes an entry from the knowledge base.

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "message": "Knowledge base entry successfully deleted"
  }
}
\`\`\`

### Conversation Management

#### List Conversations

\`\`\`
GET /chatbots/{chatbot_id}/conversations
\`\`\`

Returns a list of conversations for a specific chatbot.

**Parameters:**
- `limit` (optional): Number of results per page (default: 20)
- `offset` (optional): Pagination offset (default: 0)
- `start_date` (optional): Filter by start date
- `end_date` (optional): Filter by end date

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": [
    {
      "id": "conv_123456",
      "date": "2023-06-15",
      "message_count": 8,
      "duration": 240,
      "topics": ["Admissions", "Deadlines"]
    },
    {
      "id": "conv_789012",
      "date": "2023-06-16",
      "message_count": 5,
      "duration": 180,
      "topics": ["Financial Aid"]
    }
  ],
  "meta": {
    "total": 1245,
    "limit": 20,
    "offset": 0
  }
}
\`\`\`

#### Get Conversation Details

\`\`\`
GET /chatbots/{chatbot_id}/conversations/{conversation_id}
\`\`\`

Returns detailed information about a specific conversation.

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "id": "conv_123456",
    "date": "2023-06-15",
    "message_count": 8,
    "duration": 240,
    "topics": ["Admissions", "Deadlines"],
    "messages": [
      {
        "id": "msg_111",
        "role": "assistant",
        "content": "Hello! How can I help you today?",
        "timestamp": "2023-06-15T14:30:00Z"
      },
      {
        "id": "msg_222",
        "role": "user",
        "content": "When is the application deadline?",
        "timestamp": "2023-06-15T14:30:15Z"
      },
      {
        "id": "msg_333",
        "role": "assistant",
        "content": "The application deadline for the fall semester is August 15, 2023.",
        "timestamp": "2023-06-15T14:30:20Z"
      }
    ]
  }
}
\`\`\`

### Analytics

#### Get Chatbot Analytics

\`\`\`
GET /chatbots/{chatbot_id}/analytics
\`\`\`

Returns analytics data for a specific chatbot.

**Parameters:**
- `period` (optional): Time period (options: "day", "week", "month", "year", default: "month")
- `start_date` (optional): Start date for custom range
- `end_date` (optional): End date for custom range

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "total_conversations": 1245,
    "total_user_queries": 5678,
    "total_assistant_responses": 6789,
    "average_conversation_duration": 240,
    "top_topics": [
      {
        "name": "Admissions",
        "count": 456
      },
      {
        "name": "Financial Aid",
        "count": 345
      },
      {
        "name": "Housing",
        "count": 234
      }
    ],
    "daily_conversations": [
      {
        "date": "2023-06-01",
        "count": 45
      },
      {
        "date": "2023-06-02",
        "count": 52
      }
    ],
    "unanswered_queries": [
      {
        "query": "How do I apply for a sports scholarship?",
        "frequency": 12
      },
      {
        "query": "What is the faculty-to-student ratio?",
        "frequency": 8
      }
    ]
  }
}
\`\`\`

## Webhook Integration

Bot247 supports webhooks to notify your systems of important events:

### Register Webhook

\`\`\`
POST /webhooks
\`\`\`

Registers a new webhook endpoint.

**Request Body:**
\`\`\`json
{
  "url": "https://your-server.com/webhook",
  "events": ["conversation.created", "conversation.completed"],
  "chatbot_id": "cb_123456789"
}
\`\`\`

**Example Response:**
\`\`\`json
{
  "status": "success",
  "data": {
    "id": "wh_123456",
    "url": "https://your-server.com/webhook",
    "events": ["conversation.created", "conversation.completed"],
    "chatbot_id": "cb_123456789",
    "created_at": "2023-07-01T10:00:00Z"
  }
}
\`\`\`

### Webhook Events

Bot247 can send the following events to your webhook endpoint:

- `conversation.created`: When a new conversation starts
- `conversation.completed`: When a conversation ends
- `conversation.feedback`: When a user provides feedback
- `knowledge.updated`: When the knowledge base is updated
- `chatbot.status_changed`: When a chatbot's status changes

### Webhook Payload Example

\`\`\`json
{
  "event": "conversation.completed",
  "chatbot_id": "cb_123456789",
  "data": {
    "conversation_id": "conv_123456",
    "duration": 240,
    "message_count": 8,
    "topics": ["Admissions", "Deadlines"],
    "timestamp": "2023-06-15T14:34:00Z"
  }
}
\`\`\`

## Error Handling

The API uses standard HTTP status codes to indicate success or failure:

- `200 OK`: Request succeeded
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid request parameters
- `401 Unauthorized`: Invalid or missing API key
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server-side error

Error responses include detailed information:

\`\`\`json
{
  "status": "error",
  "error": {
    "code": "invalid_parameter",
    "message": "The parameter 'period' must be one of: day, week, month, year",
    "details": {
      "parameter": "period",
      "value": "quarter",
      "allowed_values": ["day", "week", "month", "year"]
    }
  }
}
\`\`\`

## Rate Limits

API requests are subject to rate limits:

- Pro Plan: 60 requests per minute
- Advanced Plan: 120 requests per minute

Rate limit information is included in response headers:

- `X-RateLimit-Limit`: Total requests allowed per minute
- `X-RateLimit-Remaining`: Remaining requests in the current window
- `X-RateLimit-Reset`: Time when the rate limit resets (Unix timestamp)

## Best Practices

1. **Use Pagination**: When retrieving large datasets, use pagination parameters to improve performance.

2. **Handle Rate Limits**: Implement exponential backoff when rate limits are reached.

3. **Webhook Reliability**: Ensure your webhook endpoint responds with a 200 status code quickly to acknowledge receipt.

4. **Error Handling**: Implement robust error handling to manage API failures gracefully.

5. **Caching**: Cache frequently accessed data to reduce API calls.

## Code Examples

### JavaScript/Node.js

\`\`\`javascript
const axios = require('axios');

const API_KEY = 'your_api_key';
const BASE_URL = 'https://api.bot247.live/v1';

async function getChatbots() {
  try {
    const response = await axios.get(`${BASE_URL}/chatbots`, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`
      }
    });
    
    return response.data;
  } catch (error) {
    console.error('Error fetching chatbots:', error.response?.data || error.message);
    throw error;
  }
}

// Example usage
getChatbots()
  .then(data => console.log(data))
  .catch(err => console.error(err));
\`\`\`

### Python

\`\`\`python
import requests

API_KEY = 'your_api_key'
BASE_URL = 'https://api.bot247.live/v1'

def get_chatbots():
    headers = {
        'Authorization': f'Bearer {API_KEY}'
    }
    
    response = requests.get(f'{BASE_URL}/chatbots', headers=headers)
    response.raise_for_status()  # Raise exception for 4XX/5XX responses
    
    return response.json()

# Example usage
try:
    chatbots = get_chatbots()
    print(chatbots)
except requests.exceptions.RequestException as e:
    print(f"Error fetching chatbots: {e}")
